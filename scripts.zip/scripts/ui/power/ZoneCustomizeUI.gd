extends CanvasLayer
class_name ZoneCustomizeUI
## ZoneCustomizeUI.gd  (July 2026)
## ─────────────────────────────────────────────────────────────────────────────
## Small reusable popup for customizing a wire zone's PLAYER-facing display:
## RENAME (typed text, replaces the default "Z0"/"Z1"/etc label) or RECOLOR
## (pick from a fixed 16-swatch palette). Opened by PowerTerminalUI for the
## terminal's OWN connected zone only — a terminal can only customize the
## zone it's wired into (see PowerTerminal.gd / PowerTerminalUI.gd).
##
## Persistence: PowerManager.set_zone_name()/set_zone_color_override() store
## the change keyed by the zone's stable "zone_key" identity (see
## ZoneCustomization.gd) — it survives wire add/remove/expansion exactly like
## the game's auto-assigned zone colors already do, and (per design) a
## player-picked color is NEVER overridden by the auto graph-coloring
## algorithm even if it clashes with a bordering zone's color.
##
## LIFECYCLE — same spawn-once/reuse pattern as PowerPriorityUI/
## GeneratorInspectUI: the caller keeps one instance alive (added directly to
## the scene tree root) and calls open_rename()/open_color() on it each time;
## it is never queue_free()d, only hidden via close().
##
## Built as a real Control node tree (per the "new panels use real Controls,
## not hand-drawn _draw()" convention — see GraphicsSettingsPanel.gd) since
## renaming needs a real LineEdit for text entry.
##
## MODES — only one mode's controls are visible at a time:
##   open_rename(zone_key, current_name)          — LineEdit + Apply button.
##     Enter or Apply commits and emits name_changed.
##   open_color(zone_key, current_display_color)  — 4x4 grid of the 16 fixed
##     swatches from DeviceDatabase.ZONE_PLAYER_COLOR_CHOICES. Clicking one
##     commits immediately and emits color_changed. current_display_color is
##     used only to highlight a matching swatch if the zone's current color
##     happens to already be one of the 16 choices — harmless no-op otherwise.

signal closed
signal name_changed(zone_key: String, new_name: String)
signal color_changed(zone_key: String, new_color: Color)

# ─── Palette — matches PowerTerminalUI/PowerPriorityUI military theme ───────
## All palette + geometry values sourced from BunkerTheme (the UI design
## catalog, assets/fonts/BunkerTheme.tres). Loaded in _load_theme() (from
## _ready); these defaults are fallbacks if the theme resource is missing.
var BG_COLOR:     Color = Color(0.08, 0.08, 0.09, 0.97)
## Shared backdrop dim — read from UI/backdrop_alpha_permille (Aug 2026).
var _backdrop_alpha: float = 0.60
var BORDER_COLOR: Color = Color(0.55, 0.58, 0.62, 0.70)
var HEADER_COLOR: Color = Color(0.80, 0.82, 0.86, 1.00)
var TEXT_COLOR:   Color = Color(0.85, 0.86, 0.88, 0.95)
var DIM_COLOR:    Color = Color(0.50, 0.52, 0.55, 0.80)
var ACCENT_COLOR: Color = Color(0.90, 0.80, 0.20, 1.00)   ## Jul 2026 — yellow (was green), this panel's top-stripe color

var PANEL_W:        float = 300.0
var SWATCH_SIZE:    float = 44.0
var SWATCH_GAP:     int   = 8
var GRID_COLS:      int   = 4
var panel_offset_y: float = 130.0

var _zone_key: String = ""

var _panel:     Panel = null
var _vbox:      VBoxContainer = null
var _title_lbl: Label = null

var _rename_box: VBoxContainer = null
var _name_edit:  LineEdit = null

var _color_box:      VBoxContainer = null
var _swatch_buttons: Array[Button] = []


## Pulls every palette + geometry value from BunkerTheme so the theme is the
## single source of truth (tweak there, this panel follows).
func _load_theme() -> void:
	BG_COLOR     = UIKit.theme_color("UI", "bg",     BG_COLOR)
	BORDER_COLOR = UIKit.theme_color("UI", "border", BORDER_COLOR)
	HEADER_COLOR = UIKit.theme_color("UI", "header", HEADER_COLOR)
	TEXT_COLOR   = UIKit.theme_color("UI", "text",   TEXT_COLOR)
	DIM_COLOR    = UIKit.theme_color("UI", "dim",    DIM_COLOR)
	ACCENT_COLOR = UIKit.theme_color("UI", "power_accent", ACCENT_COLOR)
	PANEL_W      = float(UIKit.theme_constant("ZoneCustomizeUI", "panel_w", 300))
	SWATCH_SIZE  = float(UIKit.theme_constant("ZoneCustomizeUI", "swatch_size", 44))
	SWATCH_GAP   = UIKit.theme_constant("ZoneCustomizeUI", "swatch_gap", 8)
	GRID_COLS    = UIKit.theme_constant("ZoneCustomizeUI", "grid_cols", 4)
	panel_offset_y = float(UIKit.theme_constant("ZoneCustomizeUI", "panel_offset_y", 130))
	_backdrop_alpha = float(UIKit.theme_constant("UI", "backdrop_alpha_permille", 600)) / 1000.0


func _ready() -> void:
	_load_theme()
	layer   = 60   ## Above PowerTerminalUI (layer 50) so it opens on top of it.
	visible = false
	## Controller navigation (Aug 2026) — d-pad + left stick drive focus,
	## B closes this UI. See scripts/ui/common/ControllerUINavigation.gd.
	var controller_nav: Node = (load("res://scripts/ui/common/ControllerUINavigation.gd") as GDScript).new()
	controller_nav.ui_root = self
	add_child(controller_nav)
	_build_ui()


func _build_ui() -> void:
	var backdrop: ColorRect = ColorRect.new()
	backdrop.set_anchors_preset(Control.PRESET_FULL_RECT)
	backdrop.color        = Color(0.0, 0.0, 0.0, _backdrop_alpha)
	backdrop.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(backdrop)

	_panel = Panel.new()
	_panel.custom_minimum_size = Vector2(PANEL_W, 0.0)
	_panel.set_anchors_preset(Control.PRESET_CENTER)
	_panel.position -= Vector2(PANEL_W * 0.5, panel_offset_y)
	var style: StyleBoxFlat = StyleBoxFlat.new()
	style.bg_color     = BG_COLOR
	style.border_color = BORDER_COLOR
	style.set_border_width_all(2)
	style.set_corner_radius_all(int(UIKit.CORNER_RADIUS))   ## Jul 2026 — was 3, now matches every other panel's radius exactly
	_panel.add_theme_stylebox_override("panel", style)
	add_child(_panel)
	_panel.add_child(UIKit.add_domain_stripe(PANEL_W, ACCENT_COLOR))

	_vbox = VBoxContainer.new()
	_vbox.add_theme_constant_override("separation", 12)
	_vbox.position = Vector2(16.0, 22.0)   ## Jul 2026 — +6px top-padding pass (Y only, matches every other panel)
	_vbox.custom_minimum_size = Vector2(PANEL_W - 32.0, 0.0)
	_panel.add_child(_vbox)

	_title_lbl = Label.new()
	_title_lbl.add_theme_font_size_override("font_size", 14)
	_title_lbl.add_theme_color_override("font_color", HEADER_COLOR)
	_vbox.add_child(_title_lbl)
	_vbox.add_child(HSeparator.new())

	## ── Rename mode controls ─────────────────────────────────────────────────
	_rename_box = VBoxContainer.new()
	_rename_box.add_theme_constant_override("separation", 8)
	_vbox.add_child(_rename_box)

	var name_lbl: Label = Label.new()
	name_lbl.text = "Zone name"
	name_lbl.add_theme_color_override("font_color", DIM_COLOR)
	_rename_box.add_child(name_lbl)

	_name_edit = LineEdit.new()
	_name_edit.max_length        = 18
	_name_edit.placeholder_text  = "Z0"
	_name_edit.text_submitted.connect(_on_name_submitted)
	_rename_box.add_child(_name_edit)

	var apply_btn: Button = Button.new()
	apply_btn.text = "Apply"
	apply_btn.pressed.connect(func() -> void: _on_name_submitted(_name_edit.text))
	_rename_box.add_child(apply_btn)

	## ── Color mode controls ──────────────────────────────────────────────────
	_color_box = VBoxContainer.new()
	_color_box.add_theme_constant_override("separation", 8)
	_vbox.add_child(_color_box)

	var color_lbl: Label = Label.new()
	color_lbl.text = "Pick a zone color"
	color_lbl.add_theme_color_override("font_color", DIM_COLOR)
	_color_box.add_child(color_lbl)

	var grid: GridContainer = GridContainer.new()
	grid.columns = GRID_COLS
	grid.add_theme_constant_override("h_separation", SWATCH_GAP)
	grid.add_theme_constant_override("v_separation", SWATCH_GAP)
	_color_box.add_child(grid)

	_swatch_buttons.clear()
	for i: int in DeviceDatabase.ZONE_PLAYER_COLOR_CHOICES.size():
		var swatch_color: Color = DeviceDatabase.ZONE_PLAYER_COLOR_CHOICES[i]
		var btn: Button = Button.new()
		btn.custom_minimum_size = Vector2(SWATCH_SIZE, SWATCH_SIZE)
		var sbox: StyleBoxFlat = StyleBoxFlat.new()
		sbox.bg_color = swatch_color
		sbox.set_border_width_all(2)
		sbox.border_color = Color(0.0, 0.0, 0.0, 0.4)
		btn.add_theme_stylebox_override("normal", sbox)
		var sbox_hover: StyleBoxFlat = sbox.duplicate()
		sbox_hover.border_color = Color(1.0, 1.0, 1.0, 0.9)
		btn.add_theme_stylebox_override("hover", sbox_hover)
		btn.add_theme_stylebox_override("pressed", sbox_hover)
		btn.pressed.connect(_on_swatch_pressed.bind(i))
		grid.add_child(btn)
		_swatch_buttons.append(btn)

	_vbox.add_child(HSeparator.new())
	var close_btn: Button = Button.new()
	close_btn.text = "Close"
	close_btn.pressed.connect(close)
	_vbox.add_child(close_btn)


## Opens in RENAME mode for the given zone.
func open_rename(zone_key: String, current_name: String) -> void:
	_zone_key = zone_key
	_title_lbl.text     = "RENAME ZONE"
	_rename_box.visible = true
	_color_box.visible  = false
	_name_edit.text     = current_name
	visible = true
	UIFade.fade_in(_panel)   ## Standing convention (July 2026) — see UIFade.gd.
	## Deferred so it grabs focus after this frame's layout/visibility settle.
	_name_edit.call_deferred("grab_focus")
	_name_edit.call_deferred("select_all")


## Opens in COLOR-PICK mode for the given zone.
func open_color(zone_key: String, current_display_color: Color) -> void:
	_zone_key = zone_key
	_title_lbl.text     = "ZONE COLOR"
	_rename_box.visible = false
	_color_box.visible  = true
	_highlight_matching_swatch(current_display_color)
	visible = true
	UIFade.fade_in(_panel)


func close() -> void:
	visible = false
	closed.emit()


func _unhandled_input(event: InputEvent) -> void:
	if not visible:
		return
	if event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
		close()
		get_viewport().set_input_as_handled()


func _on_name_submitted(text: String) -> void:
	name_changed.emit(_zone_key, text)
	close()


func _on_swatch_pressed(index: int) -> void:
	var c: Color = DeviceDatabase.ZONE_PLAYER_COLOR_CHOICES[index]
	color_changed.emit(_zone_key, c)
	close()


func _highlight_matching_swatch(current_color: Color) -> void:
	for i: int in _swatch_buttons.size():
		var btn: Button = _swatch_buttons[i]
		var swatch_color: Color = DeviceDatabase.ZONE_PLAYER_COLOR_CHOICES[i]
		var is_match: bool = swatch_color.is_equal_approx(current_color)
		var sbox: StyleBoxFlat = (btn.get_theme_stylebox("normal") as StyleBoxFlat).duplicate()
		sbox.border_color = Color(1.0, 1.0, 1.0, 0.95) if is_match else Color(0.0, 0.0, 0.0, 0.4)
		sbox.set_border_width_all(3 if is_match else 2)
		btn.add_theme_stylebox_override("normal", sbox)
