extends Control
## Custom-drawn history graph inside the native-Control Power Terminal.

const STYLE: GDScript = preload("res://scripts/ui/common/BunkerPanelStyle.gd")

var _draw_history: PackedFloat32Array = PackedFloat32Array()
var _capacity_history: PackedFloat32Array = PackedFloat32Array()


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	resized.connect(queue_redraw)


func set_history(draw_history: PackedFloat32Array,
		capacity_history: PackedFloat32Array) -> void:
	_draw_history = draw_history
	_capacity_history = capacity_history
	queue_redraw()


func _draw() -> void:
	var bounds: Rect2 = Rect2(Vector2.ZERO, size)
	draw_style_box(_box(Color("101615"), STYLE.BRASS.darkened(0.55), 5, 1), bounds)
	var plot: Rect2 = Rect2(46.0, 10.0, maxf(1.0, size.x - 64.0), maxf(1.0, size.y - 30.0))
	if plot.size.x <= 1.0 or plot.size.y <= 1.0:
		return
	var maximum: float = 1000.0
	for value: float in _draw_history:
		maximum = maxf(maximum, value)
	for value: float in _capacity_history:
		maximum = maxf(maximum, value)
	maximum = ceilf(maximum / 250.0) * 250.0
	for row: int in range(5):
		var fraction: float = float(row) / 4.0
		var y: float = plot.position.y + plot.size.y * fraction
		draw_line(Vector2(plot.position.x, y), Vector2(plot.end.x, y), Color("293231"), 1.0)
		var label_value: int = int(round(maximum * (1.0 - fraction)))
		draw_string(UIKit.font(), Vector2(4.0, y + 4.0), _axis_value(label_value),
			HORIZONTAL_ALIGNMENT_LEFT, 38.0, 11, STYLE.MUTED.darkened(0.12))
	for column: int in range(7):
		var fraction: float = float(column) / 6.0
		var x: float = plot.position.x + plot.size.x * fraction
		draw_line(Vector2(x, plot.position.y), Vector2(x, plot.end.y), Color("252d2c"), 1.0)
	_draw_series(_capacity_history, plot, maximum, STYLE.BRASS.lightened(0.35), 2.0, true)
	_draw_series(_draw_history, plot, maximum, STYLE.BLUE, 3.0, false)


func _draw_series(values: PackedFloat32Array, plot: Rect2, maximum: float,
		color: Color, width: float, dashed: bool) -> void:
	if values.size() < 2:
		return
	var points: PackedVector2Array = PackedVector2Array()
	for index: int in range(values.size()):
		var x_fraction: float = float(index) / float(maxi(values.size() - 1, 1))
		var y_fraction: float = clampf(values[index] / maximum, 0.0, 1.0)
		points.append(Vector2(plot.position.x + plot.size.x * x_fraction,
			plot.end.y - plot.size.y * y_fraction))
	if not dashed:
		draw_polyline(points, color, width, true)
		return
	for index: int in range(points.size() - 1):
		if index % 2 == 0:
			draw_line(points[index], points[index + 1], color, width, true)


func _box(background: Color, border: Color, radius: int, width: int) -> StyleBoxFlat:
	var style: StyleBoxFlat = StyleBoxFlat.new()
	style.bg_color = background
	style.border_color = border
	style.set_border_width_all(width)
	style.set_corner_radius_all(radius)
	return style


func _axis_value(value: int) -> String:
	if value >= 1000:
		return "%.1fk" % (float(value) / 1000.0)
	return str(value)
