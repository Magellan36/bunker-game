extends Control
## InventoryHUD.gd
## Draws 4 inventory slots at bottom-center of the screen.
## Each occupied slot shows a live 3D preview (SubViewport) + item name label.

const SLOT_SIZE:    float = 64.0
const SLOT_GAP:     float = 10.0
const CORNER:       float = 8.0
const LABEL_HEIGHT: float = 16.0   ## Space below the slot box for the name
const TOTAL_HEIGHT: float = SLOT_SIZE + LABEL_HEIGHT

const COLOR_BG:       Color = Color(0.10, 0.10, 0.10, 0.82)
const COLOR_BORDER:   Color = Color(0.25, 0.25, 0.25, 0.90)
const COLOR_SELECTED: Color = Color(0.55, 0.55, 0.55, 1.00)
const COLOR_LABEL:    Color = Color(0.75, 0.75, 0.75, 0.90)
const COLOR_NAME:     Color = Color(0.80, 0.78, 0.72, 0.95)

## Charge badge colours
const COLOR_CHARGE_BG:   Color = Color(0.08, 0.08, 0.08, 0.88)
const COLOR_CHARGE_FULL: Color = Color(0.75, 0.85, 0.70, 1.00)   ## greenish — has charges
const COLOR_CHARGE_LOW:  Color = Color(0.85, 0.55, 0.40, 1.00)   ## amber — last charge
const CHARGE_FONT_SIZE: int = 9                                   ## font size for badge text

## Water bottle quality badge colours (Jul 2026 bottle rework) — mirrors
## WaterDispenserUI._quality_color()'s red/yellow/green convention exactly.
## Separate meaning from the charge badge colours above (those show
## charges-remaining, these show water QUALITY 0-100).
const CRIT_COLOR:         Color = Color(1.00, 0.35, 0.30, 1.00)
const WARN_COLOR:         Color = Color(1.00, 0.72, 0.10, 1.00)
const QUALITY_GOOD_COLOR: Color = Color(0.30, 0.85, 0.35, 1.00)

## Set by MainWorld after ready
var inventory: Node = null

var _selected_slot: int = -1

## Error message overlay — fades in red text above inventory bar
var _error_label: Label    = null
var _error_tween: Tween    = null
## Items whose charge_changed signal we're currently watching
var _charge_watched: Array = []

## One SubViewport per slot — holds the 3D preview scene
var _viewports:  Array[SubViewport]    = []
var _vp_textures: Array[ViewportTexture] = []

func _ready() -> void:
	var total_w: float = SLOT_SIZE * 4 + SLOT_GAP * 3
	custom_minimum_size = Vector2(total_w, TOTAL_HEIGHT)
	_build_viewports()
	_build_error_label()

func _build_error_label() -> void:
	_error_label = Label.new()
	_error_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_error_label.add_theme_color_override("font_color", Color(0.92, 0.25, 0.25, 0.0))
	_error_label.add_theme_font_size_override("font_size", 13)
	## Positioned above the HUD bar — anchored via _process so it tracks layout
	_error_label.size = Vector2(300, 24)
	_error_label.visible = false
	add_child(_error_label)

## Shows a red fade-in/fade-out error message above the inventory bar.
## Safe to call from ShelfUI or any other system.
func show_error_message(text: String) -> void:
	if _error_label == null:
		return

	## Kill any in-progress tween first
	if _error_tween != null and _error_tween.is_valid():
		_error_tween.kill()

	_error_label.text = text
	_error_label.modulate.a = 0.0
	_error_label.visible = true

	## Centre above the HUD bar
	var bar_w: float = SLOT_SIZE * 4 + SLOT_GAP * 3
	_error_label.position = Vector2(bar_w * 0.5 - _error_label.size.x * 0.5, -32.0)

	_error_tween = create_tween()
	_error_tween.set_ease(Tween.EASE_OUT)
	_error_tween.set_trans(Tween.TRANS_QUAD)
	## Fade in 0.15s → hold 1.4s → fade out 0.45s
	_error_tween.tween_property(_error_label, "modulate:a", 1.0, 0.15)
	_error_tween.tween_interval(1.4)
	_error_tween.tween_property(_error_label, "modulate:a", 0.0, 0.45)
	_error_tween.tween_callback(func() -> void: _error_label.visible = false)

func _build_viewports() -> void:
	for i in 4:
		var vp: SubViewport = ItemPreviewKit.build_viewport(self, int(SLOT_SIZE), 1.5)
		_viewports.append(vp)

		# Grab the texture handle once — stays valid
		_vp_textures.append(vp.get_texture())

# ─── Public API ───────────────────────────────────────────────────────────────
func set_selected(slot: int) -> void:
	_selected_slot = slot
	queue_redraw()

## Called after inventory_changed — rebuilds preview meshes for all slots.
func refresh_previews() -> void:
	var slots: Array = inventory.slots if inventory != null else [null, null, null, null]
	for i in 4:
		_set_preview(i, slots[i])

	# ── Reconnect charge_changed listeners ──────────────────────────────────
	# Disconnect from any previously watched items (slots may have changed)
	for item in _charge_watched:
		if item != null and item.has_signal("charge_changed"):
			if item.charge_changed.is_connected(queue_redraw):
				item.charge_changed.disconnect(queue_redraw)
	_charge_watched.clear()

	# Connect to every currently slotted item that has the signal
	for item in slots:
		if item != null and item.has_signal("charge_changed"):
			item.charge_changed.connect(queue_redraw)
			_charge_watched.append(item)

	queue_redraw()

func _set_preview(slot_idx: int, item) -> void:
	## A slot can hold a stale freed reference (e.g. an item consumed while
	## held before its slot was cleared). is_instance_valid() is the only
	## reliable check — a freed ref can compare equal to null in Godot 4 —
	## so only ever hand set_item() a null or genuinely-valid item, never a
	## dead reference (its typed param would throw on it).
	if item == null:
		ItemPreviewKit.set_item(_viewports[slot_idx], null)
	elif is_instance_valid(item):
		ItemPreviewKit.set_item(_viewports[slot_idx], item)

# ─── Draw ─────────────────────────────────────────────────────────────────────
func _draw() -> void:
	var slots: Array = inventory.slots if inventory != null else [null, null, null, null]
	var font: Font = load("res://assets/fonts/IosevkaCharon-Regular.ttf")

	for i in 4:
		var x: float = i * (SLOT_SIZE + SLOT_GAP)
		var rect: Rect2 = Rect2(x, 0.0, SLOT_SIZE, SLOT_SIZE)

		# ── Background (Jul 2026 — was 6 separate overlapping translucent
		# draw_rect/draw_circle calls, which double-blended at every seam
		# and made the slot read as several different shades instead of one
		# flat fill; now a single UIKit.draw_rounded_rect() StyleBox-based
		# call — the same fix already used project-wide since the "rounded
		# corners" pass. Border alpha is 0 here on purpose: this call is
		# background-fill only, the actual border is drawn as its own pass
		# below, AFTER the texture, so it still renders on top of it). ──
		UIKit.draw_rounded_rect(self, rect, COLOR_BG, Color(0, 0, 0, 0), 0.0, CORNER)

		# ── SubViewport texture (3D preview) ──
		var item = slots[i] if i < slots.size() else null
		if item != null and _vp_textures[i] != null:
			draw_texture_rect(_vp_textures[i], rect, false)

		# ── Border — highlight selected (fill alpha 0 here — this pass is
		# border-only, drawn on top of the texture above) ──
		var border_col: Color = COLOR_SELECTED if i == _selected_slot else COLOR_BORDER
		UIKit.draw_rounded_rect(self, rect, Color(0, 0, 0, 0), border_col, 2.0, CORNER)

		# ── Slot number (top-left, subtle) ──
		var num: String = str(i + 1)
		draw_string(font, Vector2(x + 5.0, 13.0),
			num, HORIZONTAL_ALIGNMENT_LEFT, -1, 9,
			Color(0.40, 0.40, 0.40, 0.70))

		# ── Charge / quality badge (top-right) ──
		if item != null:
			## WaterBottle-style items (Jul 2026 rework) expose fill% + quality
			## via a dedicated contract — checked first, ahead of the generic
			## charge-count fallback chain below.
			if item.has_method("get_bottle_badge_info"):
				var bottle_info: Dictionary = item.get_bottle_badge_info()
				_draw_quality_badge(font, x,
					float(bottle_info.get("fill_mL", 0.0)),
					float(bottle_info.get("max_fill_mL", 750.0)),
					float(bottle_info.get("quality", 100.0)))
			else:
				var charge_info: Array = _get_charge_info(item)
				if charge_info.size() == 2:
					_draw_charge_badge(font, x, charge_info[0], charge_info[1])

		# ── Item name label below the slot ──
		var label_y: float = SLOT_SIZE + LABEL_HEIGHT - 3.0
		if item != null:
			var item_name: String = ""
			if item.has_method("get_display_name"):
				item_name = item.get_display_name()
			else:
				# Strip trailing numbers Godot appends (e.g. "WaterBottle2" → "Water Bottle")
				item_name = _prettify_name(item.name)

			var tsz: Vector2 = font.get_string_size(item_name, HORIZONTAL_ALIGNMENT_CENTER, -1, 9)
			var tx: float = x + SLOT_SIZE * 0.5 - tsz.x * 0.5
			draw_string(font, Vector2(tx, label_y),
				item_name, HORIZONTAL_ALIGNMENT_LEFT, -1, 9, COLOR_NAME)

# ─── Charge info ──────────────────────────────────────────────────────────────
## Returns [current, max] if the item exposes charge data, otherwise [].
## Items can implement get_charge_info() -> Array[int] for custom logic,
## or the HUD falls back to the known variable names used by FoodCan.
## NOTE: WaterBottle no longer uses this chain (sip-count model retired, Jul
## 2026) — see get_bottle_badge_info() / _draw_quality_badge() above in _draw().
func _get_charge_info(item: Node) -> Array:
	# Preferred: item implements the interface explicitly
	if item.has_method("get_charge_info"):
		return item.get_charge_info()

	# Fallback: FoodCan-style (_bites_left / TOTAL_BITES)
	if "_bites_left" in item and "TOTAL_BITES" in item:
		return [item._bites_left, item.TOTAL_BITES]

	# Fallback: generic _charges / _max_charges convention for future items
	if "_charges" in item and "_max_charges" in item:
		return [item._charges, item._max_charges]

	return []

## Draws a small rounded badge in the top-right corner of the slot.
## current/max are ints — shows "current/max" or just "current" if max == 1.
func _draw_charge_badge(font: Font, slot_x: float, current: int, max_charges: int) -> void:
	var label: String = "%d/%d" % [current, max_charges] if max_charges > 1 else str(current)

	var font_size: int = CHARGE_FONT_SIZE
	var tsz: Vector2  = font.get_string_size(label, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size)

	# Badge rect — 4px padding each side, 3px top/bottom
	const PAD_X: float = 4.0
	const PAD_Y: float = 3.0
	var bw: float = tsz.x + PAD_X * 2.0
	var bh: float = tsz.y + PAD_Y * 2.0

	# Anchor top-right of the slot with a 3px inset
	const INSET: float = 3.0
	var bx: float = slot_x + SLOT_SIZE - bw - INSET
	var by: float = INSET

	# Background pill
	var badge_rect: Rect2 = Rect2(bx, by, bw, bh)
	draw_rect(badge_rect, COLOR_CHARGE_BG, true, -1.0)

	# Text colour: amber on last charge, green otherwise
	var text_col: Color = COLOR_CHARGE_LOW if current <= 1 else COLOR_CHARGE_FULL

	# Draw text centred in badge
	draw_string(font,
		Vector2(bx + PAD_X, by + PAD_Y + tsz.y - 2.0),
		label, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, text_col)

## Draws the water-bottle-specific badge — same pill shape/position as
## _draw_charge_badge() above, but shows "Xml/Yml" on one line and "(Q%)" on
## a second line beneath it, both coloured by water QUALITY (not charge state)
## (Jul 2026 bottle rework — separate, parallel contract, see
## get_bottle_badge_info() / _bottle_quality_color() below). Two lines instead
## of one because "525ml/750ml (70%)" is far wider than the 64px slot — a
## single line would overflow into the neighbouring slot's badge.
## At 0mL the bottle presents as "Empty Water Bottle" (see
## WaterBottle.get_display_name()) — the badge mirrors that by showing a
## single dim "EMPTY" line instead of a meaningless "0ml/750ml (Q%)" readout.
func _draw_quality_badge(font: Font, slot_x: float, fill_mL: float, max_fill_mL: float, quality: float) -> void:
	if fill_mL <= 0.0:
		_draw_empty_badge(font, slot_x)
		return

	var line1: String = "%dml/%dml" % [int(round(fill_mL)), int(round(max_fill_mL))]
	var line2: String = "(%d%%)" % int(round(quality))

	var font_size: int = CHARGE_FONT_SIZE
	var tsz1: Vector2 = font.get_string_size(line1, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size)
	var tsz2: Vector2 = font.get_string_size(line2, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size)

	const PAD_X: float = 4.0
	const PAD_Y: float = 2.0
	const LINE_GAP: float = 1.0
	var bw: float = maxf(tsz1.x, tsz2.x) + PAD_X * 2.0
	var bh: float = tsz1.y + tsz2.y + LINE_GAP + PAD_Y * 2.0

	const INSET: float = 3.0
	var bx: float = slot_x + SLOT_SIZE - bw - INSET
	var by: float = INSET

	var badge_rect: Rect2 = Rect2(bx, by, bw, bh)
	draw_rect(badge_rect, COLOR_CHARGE_BG, true, -1.0)

	var text_col: Color = _bottle_quality_color(quality)

	draw_string(font,
		Vector2(bx + bw - PAD_X - tsz1.x, by + PAD_Y + tsz1.y - 2.0),
		line1, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, text_col)
	draw_string(font,
		Vector2(bx + bw - PAD_X - tsz2.x, by + PAD_Y + tsz1.y + LINE_GAP + tsz2.y - 2.0),
		line2, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, text_col)

## Single dim "EMPTY" badge — same box styling as _draw_quality_badge()'s
## two-line version, but one line, for an empty bottle (0mL).
func _draw_empty_badge(font: Font, slot_x: float) -> void:
	var label: String = "EMPTY"

	var font_size: int = CHARGE_FONT_SIZE
	var tsz: Vector2 = font.get_string_size(label, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size)

	const PAD_X: float = 4.0
	const PAD_Y: float = 3.0
	var bw: float = tsz.x + PAD_X * 2.0
	var bh: float = tsz.y + PAD_Y * 2.0

	const INSET: float = 3.0
	var bx: float = slot_x + SLOT_SIZE - bw - INSET
	var by: float = INSET

	var badge_rect: Rect2 = Rect2(bx, by, bw, bh)
	draw_rect(badge_rect, COLOR_CHARGE_BG, true, -1.0)

	draw_string(font,
		Vector2(bx + PAD_X, by + PAD_Y + tsz.y - 2.0),
		label, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, Color(0.55, 0.55, 0.55, 1.0))

## Water quality red/yellow/green convention — mirrored verbatim from
## WaterDispenserUI._quality_color() (0-50 red / 50.01-75 yellow / 75.01-100
## green, inclusive lower boundary each tier). Duplicated per this project's
## existing per-file-helper convention for water UI colour code.
func _bottle_quality_color(quality: float) -> Color:
	if quality <= 50.0:
		return CRIT_COLOR
	elif quality <= 75.0:
		return WARN_COLOR
	return QUALITY_GOOD_COLOR

# ─── Name prettifier ──────────────────────────────────────────────────────────
func _prettify_name(raw: String) -> String:
	# Strip trailing digits
	var s: String = raw.strip_edges()
	while s.length() > 0 and s[-1].is_valid_int():
		s = s.substr(0, s.length() - 1)
	# Insert spaces before capital letters (PascalCase → "Pascal Case")
	var result: String = ""
	for i in s.length():
		if i > 0 and s[i] == s[i].to_upper() and s[i] != " ":
			result += " "
		result += s[i]
	return result.strip_edges()
