extends PickupableItem
class_name FarmProduceItem
## FarmProduceItem.gd
## ─────────────────────────────────────────────────────────────────────────────
## Farming System plan §7. ONE script for both tomato/onion produce via
## export var. 1-charge, fully consumed in one on_use() call, no partial-
## bite tracking like WaterBottle's continuous-mL model.
##
## Species whose produce can be planted back into a tray instead of eaten,
## in addition to being buyable as a packet. Mirrors SeedItem.gd's plant flow.
const REPLANTABLE_TYPES: Array[String] = ["potato", "onion", "garlic"]

const TRAY_RANGE: float = 2.5   ## Matches SeedItem.gd's TRAY_RANGE

@export var produce_type: String = "tomato"   ## "tomato" or "onion"

## Flat hunger restore per produce item — same order of magnitude as
## FoodCan's per-bite value (12.5), used whole here since this is a single
## 1-charge item rather than a 2-bite can.
const FOOD_RESTORE: float = 20.0

## Visual scale per produce type — most items 2x, large items (corn, carrot,
## pumpkin) 3x. Applied to the MeshInstance3D only, collision stays at the
## original radius for gameplay consistency. Only used by the procedural
## primitive fallback path now (see PRODUCE_MODEL_SCALE for the real models).
const PRODUCE_SCALE: Dictionary = {
	"tomato": 2.0, "onion": 2.0, "basil": 2.0, "strawberry": 2.0,
	"carrot": 3.0, "chili_pepper": 2.0, "bell_pepper": 2.0, "garlic": 2.0,
	"potato": 2.0, "blueberry": 2.0, "corn": 3.0, "pumpkin": 3.0,
}

## Real model swap (Aug 2026) — per-type OBJ models (Tinkercad exports, flat
## MTL colors carried on the imported mesh) replace the procedural primitives.
## PRODUCE_MODEL_SCALE normalizes each model's largest dimension to the CURRENT
## in-game visual size (measured with the old 2x/3x PRODUCE_SCALE applied), so
## the new models read roughly the same size as the ones they replace.
## PRODUCE_MODEL_FLAT leaves that type lying flat (basil is a 2D leaf).
const PRODUCE_MODEL_PATHS: Dictionary = {
	"tomato": "res://assets/models/produce/tomato/tinker.obj",
	"onion": "res://assets/models/produce/onion/tinker.obj",
	"basil": "res://assets/models/produce/basil/tinker.obj",
	"strawberry": "res://assets/models/produce/strawberry/tinker.obj",
	"carrot": "res://assets/models/produce/carrot/tinker.obj",
	"chili_pepper": "res://assets/models/produce/chili_pepper/tinker.obj",
	"bell_pepper": "res://assets/models/produce/bell_pepper/tinker.obj",
	"garlic": "res://assets/models/produce/garlic/tinker.obj",
	"potato": "res://assets/models/produce/potato/tinker.obj",
	"blueberry": "res://assets/models/produce/blueberry/tinker.obj",
	"corn": "res://assets/models/produce/corn/tinker.obj",
	"pumpkin": "res://assets/models/produce/pumpkin/tinker.obj",
}
const PRODUCE_MODEL_SCALE: Dictionary = {
	"tomato": 0.0085, "onion": 0.0115, "basil": 0.0096, "strawberry": 0.0128,
	"carrot": 0.02195, "chili_pepper": 0.0199, "bell_pepper": 0.0143, "garlic": 0.0097,
	"potato": 0.0082, "blueberry": 0.0108, "corn": 0.0127, "pumpkin": 0.0257,
}
const PRODUCE_MODEL_FLAT: Dictionary = {
	"basil": true,
}

## Material mood override (Aug 2026) — dims, slightly desaturates and mattens
## the produce so it reads in-theme with the dark bunker instead of
## toy-bright. Applied as per-instance surface overrides (the OBJ's mesh
## materials are a shared resource) — no new textures, pure material tweaks.
const PRODUCE_MAT_DARK:      float = 0.6    ## albedo multiplier
const PRODUCE_MAT_DESAT:     float = 0.12   ## mix toward gray (0 = none)
const PRODUCE_MAT_ROUGHNESS: float = 0.8    ## kill the MTL's glossy sheen

## Collision kind per produce type (Aug 2026): round items keep a sphere
## (they can roll), long items get a cylinder oriented along their longest
## axis, and bunches / flat / oblong items (blueberries, strawberries,
## carrots, pumpkin, basil) get a box so they DON'T roll around.
const PRODUCE_COLLISION_KIND: Dictionary = {
	"tomato": "sphere", "onion": "sphere", "garlic": "sphere", "bell_pepper": "sphere",
	"potato": "cylinder", "corn": "cylinder", "chili_pepper": "cylinder",
	"pumpkin": "box", "blueberry": "box", "strawberry": "box", "carrot": "box", "basil": "box",
}

var shelf_stack_limit: int  = 6
var shelf_item_type: String = "farm_produce"   ## Shared slot for both types —
## per-instance produce_type preserved by Shelving.gd's real-node-reference
## slots, same reasoning as PurifierFilterItem/SeedItem.

var _player_stats: Node     = null
var _mesh: MeshInstance3D = null
## True when the visual came from the per-type OBJ model.
var _used_model: bool = false
## Body-space visual AABB of the loaded model (set in _build_mesh_from_model) —
## the collision shape is sized from this so it roughly matches the model.
var _model_aabb: AABB = AABB()

func _ready() -> void:
	super._ready()
	add_to_group("inventory_item")
	add_to_group("basket_storable")
	add_to_group("cookpot_storable")
	_mesh = get_node_or_null("MeshInstance3D")
	if _mesh == null:
		_build_placeholder_mesh()

func get_display_name() -> String:
	return PlantDatabase.get_display_name(produce_type)

func get_prompt_text() -> String:
	return "[F] Pick up  %s" % get_display_name()

func get_trash_material() -> String:
	return "organic"

func _find_nearest_plantable_tray() -> FarmingTray:
	if not (produce_type in REPLANTABLE_TYPES):
		return null
	var best: FarmingTray = null
	var best_dist: float = TRAY_RANGE
	for node: Node in get_tree().get_nodes_in_group("farming_tray"):
		if node is FarmingTray and (node as FarmingTray).has_open_plantable_cell():
			var d: float = global_position.distance_to((node as Node3D).global_position)
			if d < best_dist:
				best_dist = d
				best = node as FarmingTray
	return best

func get_use_prompt() -> String:
	var pot: CookingPot = CookingPot.find_nearest_open_pot(global_position, get_tree())
	if pot != null:
		var preview: Dictionary = pot.preview_add(self)
		if not preview.is_empty():
			var bonus_txt: String = "" if preview["bonus_pct"] <= 0.0 else "  (+%d%% Diversity)" % int(round(preview["bonus_pct"] * 100.0))
			return "[E] Add to Pot  →  %.1f Filling%s" % [preview["total"], bonus_txt]
	var tray: FarmingTray = _find_nearest_plantable_tray()
	if tray != null:
		return "[E] Plant %s" % get_display_name()
	return "[E] Eat  %s" % get_display_name()

## Fully consumed in one call — no charge tracking, no empty-state.
func on_use() -> void:
	var pot: CookingPot = CookingPot.find_nearest_open_pot(global_position, get_tree())
	if pot != null:
		if pot.try_add_item(self):
			CookingPot.release_from_player_hand(get_tree(), self)
			return

	## Aug 2026 per-cell interaction pass — same nearest-cell targeting as
	## SeedItem.on_use(); also deliberately ignores cell_seed_lock for the
	## same reason (player manual planting is never gated by the lock).
	var tray: FarmingTray = _find_nearest_plantable_tray()
	if tray != null:
		var cell_index: int = tray.nearest_open_plantable_cell_to(global_position)
		if cell_index >= 0 and tray.plant_seed_at_cell(cell_index, produce_type):
			queue_free()
		return

	if _player_stats == null:
		_player_stats = get_tree().get_first_node_in_group("player_stats")
	if _player_stats == null:
		push_warning("FarmProduceItem: _player_stats not found.")
		return
	_player_stats.replenish_food(consume_as_food())

## Consumes this produce (frees the node) and returns the food restored.
## Shared mutation for player + NPCs (NPC Pass 2, Part 3).
func consume_as_food() -> float:
	queue_free()
	return FOOD_RESTORE

## Dispatcher — per-type OBJ model when present, otherwise the procedural
## primitive fallback. The collision shape (small sphere / cylinder) stays on
## the RigidBody3D either way.
func _build_placeholder_mesh() -> void:
	_mesh = MeshInstance3D.new()
	var model_path: String = PRODUCE_MODEL_PATHS.get(produce_type, "")
	if model_path != "" and ResourceLoader.exists(model_path):
		_build_mesh_from_model(model_path)
	else:
		_build_mesh_from_primitives()
	add_child(_mesh)

	## Real collision shape on the RigidBody3D itself — see SeedItem.gd's
	## _build_placeholder_mesh() comment for why create_trimesh_collision()
	## was wrong here (no collider on this body at all -> infinite fall,
	## undetectable by the interaction system). Model-backed visuals get a box
	## sized to the model's actual visual AABB (rough match, per request);
	## procedural fallbacks keep their old small sphere/cylinder.
	var shape: CollisionShape3D = CollisionShape3D.new()
	if _used_model:
		_build_model_collision(shape)
	else:
		if produce_type == "corn" or produce_type == "carrot":
			## Cylindrical collision for corn/carrot so they don't roll like balls
			var cyl_shape: CylinderShape3D = CylinderShape3D.new()
			cyl_shape.radius = 0.018
			cyl_shape.height = 0.11
			shape.shape = cyl_shape
		else:
			var sphere_shape: SphereShape3D = SphereShape3D.new()
			sphere_shape.radius = 0.055
			shape.shape = sphere_shape
		shape.position = _mesh.position
	add_child(shape)

## Shapes the model-backed collision to the produce type: sphere for round
## items, cylinder (oriented along the model's longest AABB axis) for long
## items, box for bunches/flat/oblong items so they don't roll. Center sits at
## the visual AABB center; the bottom stays at y=0 (base flush with the floor).
func _build_model_collision(shape: CollisionShape3D) -> void:
	var sz: Vector3 = _model_aabb.size
	shape.position = _model_aabb.position + _model_aabb.size * 0.5
	var kind: String = PRODUCE_COLLISION_KIND.get(produce_type, "box")
	match kind:
		"sphere":
			var sp: SphereShape3D = SphereShape3D.new()
			sp.radius = maxf(sz.x, maxf(sz.y, sz.z)) * 0.5
			shape.shape = sp
		"cylinder":
			var axis: int = 1
			var longest: float = sz.y
			if sz.x > longest:
				longest = sz.x
				axis = 0
			if sz.z > longest:
				longest = sz.z
				axis = 2
			var cyl: CylinderShape3D = CylinderShape3D.new()
			cyl.height = longest
			var off_a: float = sz.y if axis == 0 else sz.x
			var off_b: float = sz.z if axis != 2 else sz.y
			cyl.radius = maxf(off_a, off_b) * 0.5
			shape.shape = cyl
			if axis == 0:
				shape.rotation.z = PI / 2.0
			elif axis == 2:
				shape.rotation.x = PI / 2.0
		_:
			var box: BoxShape3D = BoxShape3D.new()
			box.size = sz
			shape.shape = box

## Loads the per-type OBJ model and scales its largest dimension to the current
## in-game visual size (PRODUCE_MODEL_SCALE — measured with the old 2x/3x scale
## applied). Stands it upright (the OBJ's height runs along Z, Tinkercad
## exports lie flat) and lifts the base to y=0. FLAT types (basil) stay lying.
func _build_mesh_from_model(model_path: String) -> void:
	var mesh: ArrayMesh = load(model_path) as ArrayMesh
	if mesh == null:
		push_warning("FarmProduceItem: failed to load %s — falling back to primitives" % model_path)
		_build_mesh_from_primitives()
		return
	_used_model = true
	_mesh.mesh = mesh
	_apply_produce_material()
	_mesh.scale = Vector3.ONE * PRODUCE_MODEL_SCALE.get(produce_type, 0.01)
	if not PRODUCE_MODEL_FLAT.get(produce_type, false):
		_mesh.rotation.x = -PI / 2.0
	var aabb: AABB = _mesh.transform * _mesh.mesh.get_aabb()
	_mesh.position = Vector3(0.0, -aabb.position.y, 0.0)
	_model_aabb = _mesh.transform * _mesh.mesh.get_aabb()   ## final visual AABB (base at y=0)

## Dims, desaturates and mattens every surface of the loaded model via
## per-instance surface overrides (the OBJ's mesh materials are shared across
## instances, so never mutate them in place). Base color = the imported MTL
## albedo (falls back to PlantDatabase's per-type color).
func _apply_produce_material() -> void:
	if _mesh == null or _mesh.mesh == null:
		return
	for s: int in _mesh.mesh.get_surface_count():
		var base: Color = PlantDatabase.get_produce_color(produce_type)
		var existing: Material = _mesh.mesh.surface_get_material(s)
		if existing is StandardMaterial3D:
			base = (existing as StandardMaterial3D).albedo_color
		var c: Color = Color(base.r * PRODUCE_MAT_DARK, base.g * PRODUCE_MAT_DARK, base.b * PRODUCE_MAT_DARK, 1.0)
		var lum: float = c.get_luminance()
		c = c.lerp(Color(lum, lum, lum, 1.0), PRODUCE_MAT_DESAT)
		var mat := StandardMaterial3D.new()
		mat.albedo_color = c
		mat.roughness = PRODUCE_MAT_ROUGHNESS
		mat.metallic  = 0.0
		_mesh.set_surface_override_material(s, mat)

## Procedural primitive fallback (the original placeholder build) — used when
## a produce type has no real model file.
func _build_mesh_from_primitives() -> void:
	_used_model = false
	var mat: StandardMaterial3D = StandardMaterial3D.new()
	mat.albedo_color = PlantDatabase.get_produce_color(produce_type)
	mat.metallic     = PlantDatabase.get_produce_metallic(produce_type)
	mat.roughness    = PlantDatabase.get_produce_roughness(produce_type)

	match produce_type:
		"tomato":
			_build_tomato(mat)
		"onion":
			_build_onion(mat)
		"basil":
			_build_basil(mat)
		"strawberry":
			_build_strawberry(mat)
		"carrot":
			_build_carrot(mat)
		"chili_pepper":
			_build_chili_pepper(mat)
		"bell_pepper":
			_build_bell_pepper(mat)
		"garlic":
			_build_garlic(mat)
		"potato":
			_build_potato(mat)
		"blueberry":
			_build_blueberry(mat)
		"corn":
			_build_corn(mat)
		"pumpkin":
			_build_pumpkin(mat)
		_:
			_build_generic_sphere(mat)

	## Apply visual scale (2x default, 3x for corn/carrot/pumpkin)
	var scale_factor: float = PRODUCE_SCALE.get(produce_type, 2.0)
	_mesh.scale = Vector3.ONE * scale_factor

## Tomato — round sphere with small green stem cylinder on top
func _build_tomato(mat: StandardMaterial3D) -> void:
	var sphere: SphereMesh = SphereMesh.new()
	sphere.radius = 0.055
	sphere.height = 0.10
	_mesh.mesh = sphere
	_mesh.position = Vector3(0.0, 0.055, 0.0)
	_mesh.set_surface_override_material(0, mat)

	## Green stem
	var stem_mi: MeshInstance3D = MeshInstance3D.new()
	var stem: CylinderMesh = CylinderMesh.new()
	stem.top_radius = 0.006
	stem.bottom_radius = 0.008
	stem.height = 0.02
	stem.radial_segments = 6
	stem_mi.mesh = stem
	stem_mi.position = Vector3(0.0, 0.11, 0.0)
	var stem_mat: StandardMaterial3D = StandardMaterial3D.new()
	stem_mat.albedo_color = Color(0.25, 0.55, 0.15, 1.0)
	stem_mat.roughness = 0.7
	stem_mi.set_surface_override_material(0, stem_mat)
	_mesh.add_child(stem_mi)

## Onion — sphere with pointed top (tapered upper half)
func _build_onion(mat: StandardMaterial3D) -> void:
	var sphere: SphereMesh = SphereMesh.new()
	sphere.radius = 0.05
	sphere.height = 0.10
	_mesh.mesh = sphere
	_mesh.position = Vector3(0.0, 0.05, 0.0)
	_mesh.set_surface_override_material(0, mat)

	## Small pointed tip on top (divide position by 2x scale)
	var tip_mi: MeshInstance3D = MeshInstance3D.new()
	var tip: CylinderMesh = CylinderMesh.new()
	tip.top_radius = 0.003
	tip.bottom_radius = 0.012
	tip.height = 0.025
	tip.radial_segments = 6
	tip_mi.mesh = tip
	tip_mi.position = Vector3(0.0, 0.105 / 2.0, 0.0)
	tip_mi.set_surface_override_material(0, mat)
	_mesh.add_child(tip_mi)

## Basil — small cluster of 3 flat leaf-like boxes
func _build_basil(mat: StandardMaterial3D) -> void:
	## Stem
	var stem_mi: MeshInstance3D = MeshInstance3D.new()
	var stem: CylinderMesh = CylinderMesh.new()
	stem.top_radius = 0.004
	stem.bottom_radius = 0.005
	stem.height = 0.06
	stem.radial_segments = 6
	stem_mi.mesh = stem
	stem_mi.position = Vector3(0.0, 0.03, 0.0)
	var stem_mat: StandardMaterial3D = StandardMaterial3D.new()
	stem_mat.albedo_color = Color(0.18, 0.45, 0.12, 1.0)
	stem_mat.roughness = 0.7
	stem_mi.set_surface_override_material(0, stem_mat)
	_mesh.add_child(stem_mi)

	## 3 leaves fanning out
	for i in range(3):
		var leaf_mi: MeshInstance3D = MeshInstance3D.new()
		var leaf: BoxMesh = BoxMesh.new()
		leaf.size = Vector3(0.035, 0.004, 0.05)
		leaf_mi.mesh = leaf
		var angle: float = TAU * i / 3.0
		leaf_mi.position = Vector3(cos(angle) * 0.018, 0.065, sin(angle) * 0.018)
		leaf_mi.rotation.y = angle
		leaf_mi.set_surface_override_material(0, mat)
		_mesh.add_child(leaf_mi)

	_mesh.mesh = BoxMesh.new()
	_mesh.mesh.size = Vector3(0.001, 0.001, 0.001)
	_mesh.position = Vector3(0.0, 0.0, 0.0)

## Strawberry — cone/tapered shape with rounded top and calyx
func _build_strawberry(mat: StandardMaterial3D) -> void:
	## Main body — tapered cylinder (wider at top, narrow at bottom)
	var body_mi: MeshInstance3D = MeshInstance3D.new()
	var body: CylinderMesh = CylinderMesh.new()
	body.top_radius = 0.04
	body.bottom_radius = 0.012
	body.height = 0.09
	body.radial_segments = 10
	body_mi.mesh = body
	body_mi.position = Vector3(0.0, 0.045, 0.0)
	body_mi.set_surface_override_material(0, mat)
	_mesh.mesh = body
	_mesh.position = Vector3(0.0, 0.045, 0.0)
	_mesh.set_surface_override_material(0, mat)

	## Green leafy top (calyx)
	var leaf_mat: StandardMaterial3D = StandardMaterial3D.new()
	leaf_mat.albedo_color = Color(0.20, 0.50, 0.12, 1.0)
	leaf_mat.roughness = 0.7
	for i in range(5):
		var leaf_mi: MeshInstance3D = MeshInstance3D.new()
		var leaf: BoxMesh = BoxMesh.new()
		leaf.size = Vector3(0.012, 0.003, 0.025)
		leaf_mi.mesh = leaf
		var angle: float = TAU * i / 5.0
		leaf_mi.position = Vector3(cos(angle) * 0.02, 0.092, sin(angle) * 0.02)
		leaf_mi.rotation.y = angle
		leaf_mi.set_surface_override_material(0, leaf_mat)
		_mesh.add_child(leaf_mi)

## Carrot — long tapered cylinder (wider at top, pointed at bottom)
func _build_carrot(mat: StandardMaterial3D) -> void:
	var body: CylinderMesh = CylinderMesh.new()
	body.top_radius = 0.022
	body.bottom_radius = 0.004
	body.height = 0.12
	body.radial_segments = 8
	_mesh.mesh = body
	_mesh.position = Vector3(0.0, 0.06, 0.0)
	_mesh.set_surface_override_material(0, mat)

	## Green leafy top
	var leaf_mat: StandardMaterial3D = StandardMaterial3D.new()
	leaf_mat.albedo_color = Color(0.22, 0.52, 0.15, 1.0)
	leaf_mat.roughness = 0.7
	for i in range(3):
		var leaf_mi: MeshInstance3D = MeshInstance3D.new()
		var leaf: CylinderMesh = CylinderMesh.new()
		leaf.top_radius = 0.003
		leaf.bottom_radius = 0.003
		leaf.height = 0.04
		leaf.radial_segments = 4
		leaf_mi.mesh = leaf
		var angle: float = TAU * i / 3.0
		leaf_mi.position = Vector3(cos(angle) * 0.01, 0.125, sin(angle) * 0.01)
		leaf_mi.set_surface_override_material(0, leaf_mat)
		_mesh.add_child(leaf_mi)

## Chili pepper — long thin curved capsule
func _build_chili_pepper(mat: StandardMaterial3D) -> void:
	var body: CapsuleMesh = CapsuleMesh.new()
	body.radius = 0.012
	body.height = 0.10
	_mesh.mesh = body
	_mesh.position = Vector3(0.0, 0.05, 0.0)
	_mesh.rotation.z = 0.25   ## slight curve
	_mesh.set_surface_override_material(0, mat)

	## Small green stem
	var stem_mi: MeshInstance3D = MeshInstance3D.new()
	var stem: CylinderMesh = CylinderMesh.new()
	stem.top_radius = 0.004
	stem.bottom_radius = 0.006
	stem.height = 0.015
	stem.radial_segments = 6
	stem_mi.mesh = stem
	stem_mi.position = Vector3(0.0, 0.102, 0.0)
	var stem_mat: StandardMaterial3D = StandardMaterial3D.new()
	stem_mat.albedo_color = Color(0.22, 0.50, 0.15, 1.0)
	stem_mat.roughness = 0.7
	stem_mi.set_surface_override_material(0, stem_mat)
	_mesh.add_child(stem_mi)

## Bell pepper — round sphere
func _build_bell_pepper(mat: StandardMaterial3D) -> void:
	var body: SphereMesh = SphereMesh.new()
	body.radius = 0.04
	body.height = 0.07
	_mesh.mesh = body
	_mesh.position = Vector3(0.0, 0.04, 0.0)
	_mesh.set_surface_override_material(0, mat)

	## Small green stem (divide position by 2x scale)
	var stem_mi: MeshInstance3D = MeshInstance3D.new()
	var stem: CylinderMesh = CylinderMesh.new()
	stem.top_radius = 0.005
	stem.bottom_radius = 0.007
	stem.height = 0.018
	stem.radial_segments = 6
	stem_mi.mesh = stem
	stem_mi.position = Vector3(0.0, 0.082 / 2.0, 0.0)
	var stem_mat: StandardMaterial3D = StandardMaterial3D.new()
	stem_mat.albedo_color = Color(0.22, 0.50, 0.15, 1.0)
	stem_mat.roughness = 0.7
	stem_mi.set_surface_override_material(0, stem_mat)
	_mesh.add_child(stem_mi)

## Garlic — bulb shape (sphere with smaller cloves around base)
func _build_garlic(mat: StandardMaterial3D) -> void:
	var sphere: SphereMesh = SphereMesh.new()
	sphere.radius = 0.04
	sphere.height = 0.07
	_mesh.mesh = sphere
	_mesh.position = Vector3(0.0, 0.04, 0.0)
	_mesh.set_surface_override_material(0, mat)

	## Small pointed tip (divide position by 2x scale)
	var tip_mi: MeshInstance3D = MeshInstance3D.new()
	var tip: CylinderMesh = CylinderMesh.new()
	tip.top_radius = 0.002
	tip.bottom_radius = 0.008
	tip.height = 0.015
	tip.radial_segments = 6
	tip_mi.mesh = tip
	tip_mi.position = Vector3(0.0, 0.078 / 2.0, 0.0)
	tip_mi.set_surface_override_material(0, mat)
	_mesh.add_child(tip_mi)

## Potato — irregular oval (squashed sphere)
func _build_potato(mat: StandardMaterial3D) -> void:
	var sphere: SphereMesh = SphereMesh.new()
	sphere.radius = 0.045
	sphere.height = 0.075
	_mesh.mesh = sphere
	_mesh.position = Vector3(0.0, 0.04, 0.0)
	_mesh.set_surface_override_material(0, mat)

	## Small "eyes" (tiny dark indentations — just small spheres)
	var eye_mat: StandardMaterial3D = StandardMaterial3D.new()
	eye_mat.albedo_color = Color(0.45, 0.35, 0.22, 1.0)
	eye_mat.roughness = 0.9
	for i in range(3):
		var eye_mi: MeshInstance3D = MeshInstance3D.new()
		var eye: SphereMesh = SphereMesh.new()
		eye.radius = 0.005
		eye.height = 0.01
		eye_mi.mesh = eye
		var angle: float = TAU * i / 3.0
		eye_mi.position = Vector3(cos(angle) * 0.035, 0.045, sin(angle) * 0.035)
		eye_mi.set_surface_override_material(0, eye_mat)
		_mesh.add_child(eye_mi)

## Blueberry — small sphere with crown (tiny cylinder on top)
func _build_blueberry(mat: StandardMaterial3D) -> void:
	var sphere: SphereMesh = SphereMesh.new()
	sphere.radius = 0.028
	sphere.height = 0.05
	_mesh.mesh = sphere
	_mesh.position = Vector3(0.0, 0.03, 0.0)
	_mesh.set_surface_override_material(0, mat)

	## Small crown/star on top
	var crown_mi: MeshInstance3D = MeshInstance3D.new()
	var crown: CylinderMesh = CylinderMesh.new()
	crown.top_radius = 0.008
	crown.bottom_radius = 0.004
	crown.height = 0.006
	crown.radial_segments = 5
	crown_mi.mesh = crown
	crown_mi.position = Vector3(0.0, 0.058, 0.0)
	var crown_mat: StandardMaterial3D = StandardMaterial3D.new()
	crown_mat.albedo_color = Color(0.35, 0.25, 0.15, 1.0)
	crown_mat.roughness = 0.7
	crown_mi.set_surface_override_material(0, crown_mat)
	_mesh.add_child(crown_mi)

## Corn — cylinder with husk leaves peeling away from base
func _build_corn(mat: StandardMaterial3D) -> void:
	var body: CylinderMesh = CylinderMesh.new()
	body.top_radius = 0.018
	body.bottom_radius = 0.015
	body.height = 0.11
	body.radial_segments = 8
	_mesh.mesh = body
	_mesh.position = Vector3(0.0, 0.055, 0.0)
	_mesh.set_surface_override_material(0, mat)

	## Green husk leaves peeling away from the cob (rotate outward)
	var husk_mat: StandardMaterial3D = StandardMaterial3D.new()
	husk_mat.albedo_color = Color(0.30, 0.55, 0.18, 1.0)
	husk_mat.roughness = 0.7
	for i in range(3):
		var husk_mi: MeshInstance3D = MeshInstance3D.new()
		var husk: BoxMesh = BoxMesh.new()
		husk.size = Vector3(0.012, 0.05, 0.003)
		husk_mi.mesh = husk
		var angle: float = TAU * i / 3.0
		## Position at base, offset outward, rotated to peel away
		husk_mi.position = Vector3(cos(angle) * 0.025, 0.01, sin(angle) * 0.025)
		husk_mi.rotation.y = angle
		husk_mi.rotation.x = 0.4   ## tilt outward
		husk_mi.set_surface_override_material(0, husk_mat)
		_mesh.add_child(husk_mi)

	## Silk threads on top (divide position by 3x scale)
	var silk_mat: StandardMaterial3D = StandardMaterial3D.new()
	silk_mat.albedo_color = Color(0.85, 0.75, 0.30, 1.0)
	silk_mat.roughness = 0.6
	for i in range(4):
		var silk_mi: MeshInstance3D = MeshInstance3D.new()
		var silk: CylinderMesh = CylinderMesh.new()
		silk.top_radius = 0.002
		silk.bottom_radius = 0.002
		silk.height = 0.025
		silk.radial_segments = 4
		silk_mi.mesh = silk
		var angle: float = TAU * i / 4.0
		silk_mi.position = Vector3(cos(angle) * 0.008, 0.12 / 3.0, sin(angle) * 0.008)
		silk_mi.set_surface_override_material(0, silk_mat)
		_mesh.add_child(silk_mi)

## Pumpkin — smooth sphere with stem
func _build_pumpkin(mat: StandardMaterial3D) -> void:
	## Main body
	var sphere: SphereMesh = SphereMesh.new()
	sphere.radius = 0.06
	sphere.height = 0.10
	_mesh.mesh = sphere
	_mesh.position = Vector3(0.0, 0.055, 0.0)
	_mesh.set_surface_override_material(0, mat)

	## Green stem on top (divide position by 3x scale)
	var stem_mi: MeshInstance3D = MeshInstance3D.new()
	var stem: CylinderMesh = CylinderMesh.new()
	stem.top_radius = 0.006
	stem.bottom_radius = 0.010
	stem.height = 0.025
	stem.radial_segments = 6
	stem_mi.mesh = stem
	stem_mi.position = Vector3(0.0, 0.112 / 3.0, 0.0)
	var stem_mat: StandardMaterial3D = StandardMaterial3D.new()
	stem_mat.albedo_color = Color(0.25, 0.48, 0.15, 1.0)
	stem_mat.roughness = 0.7
	stem_mi.set_surface_override_material(0, stem_mat)
	_mesh.add_child(stem_mi)

## Generic fallback sphere
func _build_generic_sphere(mat: StandardMaterial3D) -> void:
	var sphere: SphereMesh = SphereMesh.new()
	sphere.radius = 0.055
	sphere.height = 0.11
	_mesh.mesh = sphere
	_mesh.position = Vector3(0.0, 0.055, 0.0)
	_mesh.set_surface_override_material(0, mat)

## Harvest pop-in tween constants (Polish Plan Group 3 item 8) — cosmetic only,
## no physics/gameplay effect. Scale-in overshoot mirrors WaterPurifier's
## play_clean_pulse() tween convention (create_tween, EASE_OUT/TRANS_BACK for
## the "pop" feel), just applied to the item's own scale instead of a ring.
const HARVEST_POP_START_SCALE: float = 0.1
const HARVEST_POP_DURATION:    float = 0.28

## Spawn helper — mirrors PurifierFilterItem.spawn_at()'s small-random-offset
## scatter pattern (used by FarmPlant.harvest() to spawn 2× per harvest).
static func spawn_at(parent: Node, base_pos: Vector3, type: String) -> FarmProduceItem:
	var item: FarmProduceItem = FarmProduceItem.new()
	item.produce_type = type
	var offset: Vector3 = Vector3(randf_range(-0.25, 0.25), 0.15, randf_range(-0.25, 0.25))
	parent.add_child(item)
	item.global_position = base_pos + offset

	## Harvest pop-in (Group 3 item 8): starts tiny, scales up past full size
	## and settles — a quick "pop" so freshly-harvested produce reads clearly
	## instead of just appearing at full size.
	item.scale = Vector3.ONE * HARVEST_POP_START_SCALE
	var tween: Tween = item.create_tween()
	tween.set_ease(Tween.EASE_OUT)
	tween.set_trans(Tween.TRANS_BACK)
	tween.tween_property(item, "scale", Vector3.ONE, HARVEST_POP_DURATION)

	return item
