extends StaticBody3D
class_name GeneratorObject
## GeneratorObject.gd
## Procedural generator mesh (gray box). Sized by tier.
## Registers itself with PowerManager on _ready, unregisters on _exit_tree.
## Tier 0 = Small (1×1, 800W), Tier 1 = Med (1×2, 2000W), Tier 2 = Large (2×2, 5000W).
## Fuel banner: shows "XX% FUEL" above the generator when player is nearby.
## Wire socket: small emissive sphere at the wire connection point on the side face.
## Interaction (E key): opens GeneratorInspectUI panel with fuel bar, HP, backup toggle, grid state.

# ─── Debug ────────────────────────────────────────────────────────────────────
## Flip false to silence all [GEN] registration/ready prints.
const WIRE_DEBUG: bool = true
func _wdbg(msg: String) -> void:
	if WIRE_DEBUG:
		print(msg)

# ─── Tier config ──────────────────────────────────────────────────────────────
const TIER_CONFIG: Array = [
	{ "size": Vector3(0.57, 0.85, 0.85), "watts": 800,  "label": "Generator S" },
	{ "size": Vector3(1.24, 1.13, 0.62), "watts": 2000, "label": "Generator M" },
	{ "size": Vector3(1.85, 1.70, 0.925), "watts": 5000, "label": "Generator L" },
]

const COLOR_BODY:     Color = Color(0.38, 0.38, 0.38, 1.0)
const COLOR_PANEL:    Color = Color(0.25, 0.25, 0.28, 1.0)
const COLOR_RUNNING:  Color = Color(0.15, 0.90, 0.20, 1.0)
const COLOR_STOPPED:  Color = Color(0.85, 0.18, 0.12, 1.0)
const COLOR_GENL_GREEN: Color = Color(0.18, 0.52, 0.34, 1.0)   ## industrial green panels
const COLOR_GENM_WHITE: Color = Color(0.92, 0.92, 0.90, 1.0)   ## white panels
const COLOR_GENL_BLACK: Color = Color(0.10, 0.10, 0.10, 1.0)   ## black base/skid
const COLOR_GENS_DARK: Color = Color(0.18, 0.18, 0.20, 1.0)   ## dark grey body
const COLOR_GENS_RED: Color = Color(0.85, 0.15, 0.10, 1.0)   ## red accent stripe

## Wire socket — small emissive sphere on the generator side face (−Z face).
## Indicates where a wire should be connected. Cyan when running, dim when off.
## SOCKET_RADIUS / SOCKET_COLOR_ON / SOCKET_COLOR_OFF removed with back-face socket mesh.

# ─── Exports ──────────────────────────────────────────────────────────────────
@export var generator_tier: int = 0

# ─── Internal refs ────────────────────────────────────────────────────────────
var _indicator_mi:  MeshInstance3D     = null
var _indicator_mat: StandardMaterial3D = null

var _is_running:    bool               = false
var _exhaust:        GPUParticles3D    = null   ## exhaust smoke, see _build_exhaust()
var _is_backup:     bool               = false
var _pm_id:         String             = ""
var _wire_key:      String             = ""

var _pm_retry_count: int = 0

var _inspect_ui: Node = null
var _inspect_refresh_queued: bool = false

var _grid_tripped: bool = false

## Full-fidelity preview mode (Jul 2026) — set TRUE by BuildModeHUD's
## construct-tab preview code BEFORE add_child(), so this instance builds
## its real visual exactly like a placed object but skips every
## side-effecting call (group membership, PowerManager/WaterManager
## registration). MUST be set before add_child() — _ready() fires
## synchronously during add_child() and reads this immediately. See
## docs/systems/build/README.md "Full-fidelity previews" for the full
## convention and why this exists (a previous version instantiated these
## same scripts with no guard and registered 3 real running generators
## into the live PowerManager the instant Build Mode opened).
var _is_preview_only: bool = false

# ─── Fuel banner ──────────────────────────────────────────────────────────────
const BANNER_HEIGHT_ABOVE: float = 0.45
var _fuel_banner:     Label3D = null
var _fuel_level:      float   = 100.0
var _player_in_range: bool    = false

# ─── Ready ────────────────────────────────────────────────────────────────────
func _ready() -> void:
	_wdbg("[GEN] _ready fired — tier=%d instance_id=%d" % [generator_tier, get_instance_id()])
	generator_tier = clamp(generator_tier, 0, 2)
	collision_layer = 5
	collision_mask  = 0
	if not _is_preview_only:
		add_to_group("generator")
		add_to_group("interactable")
	_build_mesh()
	_build_fuel_banner()
	if _is_preview_only:
		return
	## Defer registration one frame so PowerManager is guaranteed to be in its group.
	call_deferred("_register_with_pm")

# ─── Fuel banner ──────────────────────────────────────────────────────────────
func _build_fuel_banner() -> void:
	var sz: Vector3 = TIER_CONFIG[generator_tier]["size"]
	var lbl: Label3D = Label3D.new()
	lbl.text          = "100% FUEL"
	lbl.font_size     = 52
	lbl.pixel_size    = 0.0018
	lbl.billboard     = BaseMaterial3D.BILLBOARD_ENABLED
	lbl.no_depth_test = true
	lbl.modulate      = Color(0.90, 0.95, 0.90, 1.0)
	lbl.position      = Vector3(0.0, sz.y + BANNER_HEIGHT_ABOVE + 0.10, 0.0)
	lbl.visible       = false
	add_child(lbl)
	_fuel_banner = lbl

func _refresh_fuel_banner() -> void:
	if _fuel_banner == null:
		return
	var pct: int = int(clampf(_fuel_level, 0.0, 100.0))
	_fuel_banner.text = "%d%% FUEL" % pct
	if pct >= 50:
		_fuel_banner.modulate = Color(0.50, 1.00, 0.55, 1.0)
	elif pct >= 20:
		_fuel_banner.modulate = Color(1.00, 0.75, 0.15, 1.0)
	else:
		_fuel_banner.modulate = Color(1.00, 0.25, 0.15, 1.0)

func set_player_in_range(in_range: bool) -> void:
	_player_in_range = in_range
	if _fuel_banner != null:
		_fuel_banner.visible = in_range
	if in_range and _fuel_banner != null:
		_refresh_fuel_banner()

# ─── Build mesh ───────────────────────────────────────────────────────────────
func _build_mesh() -> void:
	var cfg: Dictionary = TIER_CONFIG[generator_tier]
	var sz: Vector3 = cfg["size"]

	## Body
	var body_mi:   MeshInstance3D  = MeshInstance3D.new()
	var body_mesh: BoxMesh         = BoxMesh.new()
	body_mesh.size = sz
	body_mi.mesh   = body_mesh
	body_mi.position = Vector3(0.0, sz.y * 0.5, 0.0)

	var body_mat: StandardMaterial3D = StandardMaterial3D.new()
	body_mat.albedo_color = COLOR_BODY
	body_mat.roughness    = 0.85
	body_mat.metallic     = 0.40
	body_mi.set_surface_override_material(0, body_mat)
	add_child(body_mi)

	body_mi.create_trimesh_collision()
	for child in body_mi.get_children():
		if child is StaticBody3D:
			(child as StaticBody3D).collision_layer = 5
			(child as StaticBody3D).collision_mask  = 0

	## Front control panel
	var panel_mi:   MeshInstance3D = MeshInstance3D.new()
	var panel_mesh: BoxMesh        = BoxMesh.new()
	var pw: float = sz.x * 0.70
	var ph: float = sz.y * 0.55
	panel_mesh.size  = Vector3(pw, ph, 0.04)
	panel_mi.mesh    = panel_mesh
	panel_mi.position = Vector3(0.0, sz.y * 0.5, sz.z * 0.5 + 0.02)

	var panel_mat: StandardMaterial3D = StandardMaterial3D.new()
	panel_mat.albedo_color = COLOR_PANEL
	panel_mat.roughness    = 0.70
	panel_mi.set_surface_override_material(0, panel_mat)
	add_child(panel_mi)

	## Status indicator LED
	_indicator_mi = MeshInstance3D.new()
	var ind_mesh: BoxMesh = BoxMesh.new()
	ind_mesh.size        = Vector3(0.09, 0.09, 0.04)
	_indicator_mi.mesh   = ind_mesh
	_indicator_mi.position = Vector3(pw * 0.30, sz.y * 0.5 + ph * 0.22, sz.z * 0.5 + 0.04)

	_indicator_mat = StandardMaterial3D.new()
	_indicator_mat.albedo_color              = COLOR_STOPPED
	_indicator_mat.emission_enabled          = true
	_indicator_mat.emission                  = COLOR_STOPPED
	_indicator_mat.emission_energy_multiplier = 1.5
	_indicator_mi.set_surface_override_material(0, _indicator_mat)
	add_child(_indicator_mi)

	## Wire socket sphere removed — wire node is at the generator centre (global_position).
	## The centre snap dot shown in Build Mode is sufficient; the back-face sphere
	## was a duplicate connection point that confused placement.

	## Generator S specific details: dark grey body, red stripe, control panel, emergency stop
	if generator_tier == 0:
		## Dark panels wrapping all 4 vertical faces
		var dark_mat: StandardMaterial3D = StandardMaterial3D.new()
		dark_mat.albedo_color = COLOR_GENS_DARK
		dark_mat.roughness    = 0.60
		dark_mat.metallic     = 0.40

		## Front panel (+Z)
		var sf_mi: MeshInstance3D = MeshInstance3D.new()
		var sf: BoxMesh = BoxMesh.new()
		sf.size = Vector3(sz.x * 0.96, sz.y * 0.90, 0.022)
		sf_mi.mesh = sf
		sf_mi.position = Vector3(0.0, sz.y * 0.50, sz.z * 0.5 + 0.015)
		sf_mi.set_surface_override_material(0, dark_mat)
		add_child(sf_mi)

		## Back panel (-Z)
		var sb_mi: MeshInstance3D = MeshInstance3D.new()
		var sb: BoxMesh = BoxMesh.new()
		sb.size = Vector3(sz.x * 0.96, sz.y * 0.90, 0.022)
		sb_mi.mesh = sb
		sb_mi.position = Vector3(0.0, sz.y * 0.50, -sz.z * 0.5 - 0.015)
		sb_mi.set_surface_override_material(0, dark_mat)
		add_child(sb_mi)

		## Left panel (+X)
		var sl_mi: MeshInstance3D = MeshInstance3D.new()
		var sl: BoxMesh = BoxMesh.new()
		sl.size = Vector3(0.022, sz.y * 0.90, sz.z * 0.96)
		sl_mi.mesh = sl
		sl_mi.position = Vector3(sz.x * 0.5 + 0.015, sz.y * 0.50, 0.0)
		sl_mi.set_surface_override_material(0, dark_mat)
		add_child(sl_mi)

		## Right panel (-X)
		var sr_mi: MeshInstance3D = MeshInstance3D.new()
		var sr: BoxMesh = BoxMesh.new()
		sr.size = Vector3(0.022, sz.y * 0.90, sz.z * 0.96)
		sr_mi.mesh = sr
		sr_mi.position = Vector3(-sz.x * 0.5 - 0.015, sz.y * 0.50, 0.0)
		sr_mi.set_surface_override_material(0, dark_mat)
		add_child(sr_mi)

		## Red horizontal stripe (front face)
		var stripe_mi: MeshInstance3D = MeshInstance3D.new()
		var stripe: BoxMesh = BoxMesh.new()
		stripe.size = Vector3(sz.x * 0.94, sz.y * 0.12, 0.024)
		stripe_mi.mesh = stripe
		stripe_mi.position = Vector3(0.0, sz.y * 0.45, sz.z * 0.5 + 0.018)
		var stripe_mat: StandardMaterial3D = StandardMaterial3D.new()
		stripe_mat.albedo_color = COLOR_GENS_RED
		stripe_mat.roughness    = 0.40
		stripe_mat.metallic     = 0.50
		stripe_mi.set_surface_override_material(0, stripe_mat)
		add_child(stripe_mi)

		## Control panel inset (upper front)
		var ctrl_mi: MeshInstance3D = MeshInstance3D.new()
		var ctrl: BoxMesh = BoxMesh.new()
		ctrl.size = Vector3(sz.x * 0.70, sz.y * 0.28, 0.025)
		ctrl_mi.mesh = ctrl
		ctrl_mi.position = Vector3(0.0, sz.y * 0.72, sz.z * 0.5 + 0.018)
		var ctrl_mat: StandardMaterial3D = StandardMaterial3D.new()
		ctrl_mat.albedo_color = Color(0.12, 0.12, 0.15, 1.0)
		ctrl_mat.roughness    = 0.60
		ctrl_mat.metallic     = 0.50
		ctrl_mi.set_surface_override_material(0, ctrl_mat)
		add_child(ctrl_mi)

		## Emergency stop button (red circle, lower front)
		var estop_mi: MeshInstance3D = MeshInstance3D.new()
		var estop: CylinderMesh = CylinderMesh.new()
		estop.top_radius    = 0.035
		estop.bottom_radius = 0.035
		estop.height        = 0.025
		estop.radial_segments = 16
		estop_mi.mesh = estop
		estop_mi.position = Vector3(-sz.x * 0.25, sz.y * 0.32, sz.z * 0.5 + 0.025)
		estop_mi.rotation.x = PI * 0.5
		var estop_mat: StandardMaterial3D = StandardMaterial3D.new()
		estop_mat.albedo_color = Color(0.90, 0.10, 0.08, 1.0)
		estop_mat.roughness    = 0.35
		estop_mat.metallic     = 0.55
		estop_mi.set_surface_override_material(0, estop_mat)
		add_child(estop_mi)

		## Handle on top (black bar)
		var handle_mi: MeshInstance3D = MeshInstance3D.new()
		var handle: BoxMesh = BoxMesh.new()
		handle.size = Vector3(sz.x * 0.50, 0.025, 0.025)
		handle_mi.mesh = handle
		handle_mi.position = Vector3(0.0, sz.y + 0.02, 0.0)
		var handle_mat: StandardMaterial3D = StandardMaterial3D.new()
		handle_mat.albedo_color = COLOR_GENL_BLACK
		handle_mat.roughness    = 0.40
		handle_mat.metallic     = 0.60
		handle_mi.set_surface_override_material(0, handle_mat)
		add_child(handle_mi)

		## Handle supports (two vertical bars)
		for hx in [-sz.x * 0.20, sz.x * 0.20]:
			var supp_mi: MeshInstance3D = MeshInstance3D.new()
			var supp: BoxMesh = BoxMesh.new()
			supp.size = Vector3(0.020, 0.04, 0.020)
			supp_mi.mesh = supp
			supp_mi.position = Vector3(hx, sz.y + 0.005, 0.0)
			supp_mi.set_surface_override_material(0, handle_mat)
			add_child(supp_mi)

		## Ventilation slots on side (3 horizontal slats)
		var vent_mat: StandardMaterial3D = StandardMaterial3D.new()
		vent_mat.albedo_color = COLOR_GENL_BLACK
		vent_mat.roughness    = 0.70
		vent_mat.metallic     = 0.30
		for i in range(3):
			var vent_mi: MeshInstance3D = MeshInstance3D.new()
			var vent: BoxMesh = BoxMesh.new()
			vent.size = Vector3(0.024, 0.015, sz.z * 0.40)
			vent_mi.mesh = vent
			vent_mi.position = Vector3(-sz.x * 0.5 - 0.018, sz.y * 0.18 + float(i) * 0.035, 0.0)
			vent_mi.set_surface_override_material(0, vent_mat)
			add_child(vent_mi)

	## Generator L specific details: green panels, black base, doors, louvers
	elif generator_tier == 2:
		## Black base/skid at bottom
		var base_mi: MeshInstance3D = MeshInstance3D.new()
		var base: BoxMesh = BoxMesh.new()
		base.size = Vector3(sz.x * 0.98, sz.y * 0.15, sz.z * 0.98)
		base_mi.mesh = base
		base_mi.position = Vector3(0.0, sz.y * 0.075, 0.0)
		var base_mat: StandardMaterial3D = StandardMaterial3D.new()
		base_mat.albedo_color = COLOR_GENL_BLACK
		base_mat.roughness    = 0.80
		base_mat.metallic     = 0.35
		base_mi.set_surface_override_material(0, base_mat)
		add_child(base_mi)

		## Green panels wrapping all 4 vertical faces
		var green_mat: StandardMaterial3D = StandardMaterial3D.new()
		green_mat.albedo_color = COLOR_GENL_GREEN
		green_mat.roughness    = 0.55
		green_mat.metallic     = 0.45

		## Front panel (+Z)
		var gf_mi: MeshInstance3D = MeshInstance3D.new()
		var gf: BoxMesh = BoxMesh.new()
		gf.size = Vector3(sz.x * 0.96, sz.y * 0.78, 0.022)
		gf_mi.mesh = gf
		gf_mi.position = Vector3(0.0, sz.y * 0.50, sz.z * 0.5 + 0.015)
		gf_mi.set_surface_override_material(0, green_mat)
		add_child(gf_mi)

		## Back panel (-Z)
		var gb_mi: MeshInstance3D = MeshInstance3D.new()
		var gb: BoxMesh = BoxMesh.new()
		gb.size = Vector3(sz.x * 0.96, sz.y * 0.78, 0.022)
		gb_mi.mesh = gb
		gb_mi.position = Vector3(0.0, sz.y * 0.50, -sz.z * 0.5 - 0.015)
		gb_mi.set_surface_override_material(0, green_mat)
		add_child(gb_mi)

		## Left panel (+X)
		var gl_mi: MeshInstance3D = MeshInstance3D.new()
		var gl: BoxMesh = BoxMesh.new()
		gl.size = Vector3(0.022, sz.y * 0.78, sz.z * 0.96)
		gl_mi.mesh = gl
		gl_mi.position = Vector3(sz.x * 0.5 + 0.015, sz.y * 0.50, 0.0)
		gl_mi.set_surface_override_material(0, green_mat)
		add_child(gl_mi)

		## Right panel (-X)
		var gr_mi: MeshInstance3D = MeshInstance3D.new()
		var gr: BoxMesh = BoxMesh.new()
		gr.size = Vector3(0.022, sz.y * 0.78, sz.z * 0.96)
		gr_mi.mesh = gr
		gr_mi.position = Vector3(-sz.x * 0.5 - 0.015, sz.y * 0.50, 0.0)
		gr_mi.set_surface_override_material(0, green_mat)
		add_child(gr_mi)

		## Door panels with handles (front)
		var door_w: float = sz.x * 0.30
		_add_door(self, sz, -sz.x * 0.22, door_w)
		_add_door(self, sz, sz.x * 0.22, door_w)

		## Louvers on right side (−X face) — horizontal slats
		_add_louvers(self, sz, 7)

	## Generator M specific details: white panels, black base, doors, louvers
	elif generator_tier == 1:
		## Black base/skid at bottom
		var base_mi: MeshInstance3D = MeshInstance3D.new()
		var base: BoxMesh = BoxMesh.new()
		base.size = Vector3(sz.x * 0.98, sz.y * 0.15, sz.z * 0.98)
		base_mi.mesh = base
		base_mi.position = Vector3(0.0, sz.y * 0.075, 0.0)
		var base_mat: StandardMaterial3D = StandardMaterial3D.new()
		base_mat.albedo_color = COLOR_GENL_BLACK
		base_mat.roughness    = 0.80
		base_mat.metallic     = 0.35
		base_mi.set_surface_override_material(0, base_mat)
		add_child(base_mi)

		## White panels wrapping all 4 vertical faces
		var white_mat: StandardMaterial3D = StandardMaterial3D.new()
		white_mat.albedo_color = COLOR_GENM_WHITE
		white_mat.roughness    = 0.55
		white_mat.metallic     = 0.45

		## Front panel (+Z)
		var wf_mi: MeshInstance3D = MeshInstance3D.new()
		var wf: BoxMesh = BoxMesh.new()
		wf.size = Vector3(sz.x * 0.96, sz.y * 0.78, 0.022)
		wf_mi.mesh = wf
		wf_mi.position = Vector3(0.0, sz.y * 0.50, sz.z * 0.5 + 0.015)
		wf_mi.set_surface_override_material(0, white_mat)
		add_child(wf_mi)

		## Back panel (-Z)
		var wb_mi: MeshInstance3D = MeshInstance3D.new()
		var wb: BoxMesh = BoxMesh.new()
		wb.size = Vector3(sz.x * 0.96, sz.y * 0.78, 0.022)
		wb_mi.mesh = wb
		wb_mi.position = Vector3(0.0, sz.y * 0.50, -sz.z * 0.5 - 0.015)
		wb_mi.set_surface_override_material(0, white_mat)
		add_child(wb_mi)

		## Left panel (+X)
		var wl_mi: MeshInstance3D = MeshInstance3D.new()
		var wl: BoxMesh = BoxMesh.new()
		wl.size = Vector3(0.022, sz.y * 0.78, sz.z * 0.96)
		wl_mi.mesh = wl
		wl_mi.position = Vector3(sz.x * 0.5 + 0.015, sz.y * 0.50, 0.0)
		wl_mi.set_surface_override_material(0, white_mat)
		add_child(wl_mi)

		## Right panel (-X)
		var wr_mi: MeshInstance3D = MeshInstance3D.new()
		var wr: BoxMesh = BoxMesh.new()
		wr.size = Vector3(0.022, sz.y * 0.78, sz.z * 0.96)
		wr_mi.mesh = wr
		wr_mi.position = Vector3(-sz.x * 0.5 - 0.015, sz.y * 0.50, 0.0)
		wr_mi.set_surface_override_material(0, white_mat)
		add_child(wr_mi)

		## Door panels with handles (front)
		var door_w: float = sz.x * 0.30
		_add_door(self, sz, -sz.x * 0.22, door_w, COLOR_GENM_WHITE)

		## Control panel inset on right side of front face
		var ctrl_mi: MeshInstance3D = MeshInstance3D.new()
		var ctrl: BoxMesh = BoxMesh.new()
		ctrl.size = Vector3(sz.x * 0.35, sz.y * 0.35, 0.025)
		ctrl_mi.mesh = ctrl
		ctrl_mi.position = Vector3(sz.x * 0.28, sz.y * 0.55, sz.z * 0.5 + 0.018)
		var ctrl_mat: StandardMaterial3D = StandardMaterial3D.new()
		ctrl_mat.albedo_color = Color(0.15, 0.15, 0.18, 1.0)
		ctrl_mat.roughness    = 0.60
		ctrl_mat.metallic     = 0.50
		ctrl_mi.set_surface_override_material(0, ctrl_mat)
		add_child(ctrl_mi)

		## Louvers on right side — horizontal slats
		_add_louvers(self, sz, 5)

	_build_exhaust(sz)


## Side louver vent (horizontal slats on the side face)
func _add_louvers(parent: Node3D, sz: Vector3, count: int) -> void:
	var louver_mat: StandardMaterial3D = StandardMaterial3D.new()
	louver_mat.albedo_color = COLOR_GENL_BLACK
	louver_mat.roughness    = 0.75
	louver_mat.metallic     = 0.30
	var slat_w: float = sz.z * 0.85
	for i in range(count):
		var slat_mi: MeshInstance3D = MeshInstance3D.new()
		var slat: BoxMesh = BoxMesh.new()
		slat.size = Vector3(slat_w, 0.018, 0.015)
		slat_mi.mesh = slat
		slat_mi.set_surface_override_material(0, louver_mat)
		var y_pos: float = sz.y * 0.35 + (float(i) / float(count - 1)) * sz.y * 0.45
		slat_mi.position = Vector3(0.0, y_pos, sz.z * 0.5 + 0.012)
		parent.add_child(slat_mi)

## Door panel with handle (front face detail for Generator L/M)
func _add_door(parent: Node3D, sz: Vector3, x_offset: float, door_w: float, door_color: Color = COLOR_GENL_GREEN) -> void:
	var door_mat: StandardMaterial3D = StandardMaterial3D.new()
	door_mat.albedo_color = door_color
	door_mat.roughness    = 0.55
	door_mat.metallic     = 0.45
	var door_mi: MeshInstance3D = MeshInstance3D.new()
	var door: BoxMesh = BoxMesh.new()
	door.size = Vector3(door_w, sz.y * 0.72, 0.025)
	door_mi.mesh = door
	door_mi.set_surface_override_material(0, door_mat)
	door_mi.position = Vector3(x_offset, sz.y * 0.48, sz.z * 0.5 + 0.018)
	parent.add_child(door_mi)

	## Handle (small horizontal bar)
	var handle_mat: StandardMaterial3D = StandardMaterial3D.new()
	handle_mat.albedo_color = COLOR_GENL_BLACK
	handle_mat.roughness    = 0.40
	handle_mat.metallic     = 0.70
	var handle_mi: MeshInstance3D = MeshInstance3D.new()
	var handle: BoxMesh = BoxMesh.new()
	handle.size = Vector3(0.04, 0.018, 0.018)
	handle_mi.mesh = handle
	handle_mi.set_surface_override_material(0, handle_mat)
	handle_mi.position = Vector3(x_offset + door_w * 0.35, sz.y * 0.50, sz.z * 0.5 + 0.035)
	parent.add_child(handle_mi)


## _build_wire_socket removed — back-face socket sphere was a duplicate snap point.

## Graphics plan Section 4 VFX priority #5 — continuous light exhaust smoke
## while running. Deliberately NOT scaled to fuel-burn/load rate (would need
## wiring into the solver's draw accounting — a bigger change than a
## constant-rate cosmetic puff justifies for this pass); toggled fully
## on/off with _is_running via set_running() instead.
func _build_exhaust(sz: Vector3) -> void:
	_exhaust = GPUParticles3D.new()
	_exhaust.amount       = 10
	_exhaust.lifetime     = 2.0
	_exhaust.local_coords = true
	_exhaust.position     = Vector3(0.0, sz.y + 0.05, -sz.z * 0.35)
	_exhaust.emitting     = false

	var mesh: QuadMesh = QuadMesh.new()
	mesh.size = Vector2(0.10, 0.10)
	var mat: StandardMaterial3D = StandardMaterial3D.new()
	mat.albedo_texture   = load("res://assets/textures/vfx/smoke_puff.png")
	mat.albedo_color     = Color(0.55, 0.55, 0.55, 0.45)
	mat.shading_mode     = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.transparency     = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.billboard_mode   = BaseMaterial3D.BILLBOARD_PARTICLES
	mesh.material = mat
	_exhaust.draw_pass_1 = mesh

	var pmat: ParticleProcessMaterial = ParticleProcessMaterial.new()
	pmat.direction            = Vector3(0.0, 1.0, 0.0)
	pmat.spread               = 25.0
	pmat.initial_velocity_min = 0.15
	pmat.initial_velocity_max = 0.35
	pmat.gravity              = Vector3(0.0, 0.05, 0.0)
	pmat.scale_min            = 1.0
	pmat.scale_max            = 2.2
	_exhaust.process_material = pmat

	add_child(_exhaust)
## Wire node is registered at global_position (generator centre). _sync_socket
## is a no-op kept for call-site compatibility.
func _sync_socket() -> void:
	pass   ## socket mesh removed; nothing to sync


# ─── PowerManager registration ────────────────────────────────────────────────
const _PM_MAX_RETRIES: int = 5

func _register_with_pm() -> void:
	var pm: PowerManager = get_tree().get_first_node_in_group("power_manager") as PowerManager
	_wdbg("[GEN] _register_with_pm attempt=%d — pm_found=%s instance_id=%d" % [
		_pm_retry_count, str(pm != null), get_instance_id()])
	if pm == null:
		_pm_retry_count += 1
		if _pm_retry_count < _PM_MAX_RETRIES:
			push_warning("GeneratorObject: PowerManager not found, retry %d/%d next frame" % [
				_pm_retry_count, _PM_MAX_RETRIES])
			call_deferred("_register_with_pm")
		else:
			push_error("GeneratorObject: PowerManager not found after %d retries — generator will not produce power" % _PM_MAX_RETRIES)
		return
	_pm_id = str(get_instance_id())
	var cfg: Dictionary = TIER_CONFIG[generator_tier]
	_wdbg("[GEN] calling register_generator id=%s watts=%.0f" % [_pm_id, cfg["watts"]])
	pm.register_generator(_pm_id, cfg["watts"], self, false, 100.0, 100.0)
	pm.set_generator_running(_pm_id, true)
	_is_running = true
	_sync_indicator()
	_sync_socket()
	if pm.has_signal("generator_fuel_low") and not pm.generator_fuel_low.is_connected(_on_fuel_low):
		pm.generator_fuel_low.connect(_on_fuel_low)
	if pm.has_signal("grid_tripped") and not pm.grid_tripped.is_connected(_on_pm_grid_tripped):
		pm.grid_tripped.connect(_on_pm_grid_tripped)
	if pm.has_signal("grid_restored") and not pm.grid_restored.is_connected(_on_pm_grid_restored):
		pm.grid_restored.connect(_on_pm_grid_restored)
	# Keep the open inspector current for solves and all grid states, not just
	# tripped/restored. Data still comes from PowerManager; the UI never polls it.
	if not pm.draw_changed.is_connected(_on_inspector_power_changed):
		pm.draw_changed.connect(_on_inspector_power_changed)
	if not pm.grid_state_changed.is_connected(_on_inspector_grid_changed):
		pm.grid_state_changed.connect(_on_inspector_grid_changed)
	call_deferred("_register_wire_deferred")

func _register_wire_deferred() -> void:
	var pm: PowerManager = get_tree().get_first_node_in_group("power_manager") as PowerManager
	_wdbg("[GEN] _register_wire_deferred — pm_found=%s pm_id='%s' gpos=%s" % [
		str(pm != null), _pm_id, str(global_position)])
	if pm == null or _pm_id.is_empty():
		push_warning("GeneratorObject: _register_wire_deferred skipped — pm=%s pm_id='%s'" % [
			str(pm != null), _pm_id])
		return
	## Pass Y=1.0 explicitly so the snap key lands on the canonical wire-grid
	## plane, matching perimeter nodes.  PowerManager also normalises this, but
	## being explicit here keeps stored world position correct too.
	var wire_pos: Vector3 = Vector3(global_position.x, 1.0, global_position.z)
	_wire_key = pm.register_wire_node(wire_pos, "generator", _pm_id)
	_wdbg("[GEN] wire node registered: key=%s" % _wire_key)
	## Generators must be manually wired — no auto-connect.


func _on_fuel_low(gen_id: String, fuel_pct: float) -> void:
	if gen_id != _pm_id:
		return
	_fuel_level = fuel_pct
	if _player_in_range and _fuel_banner != null:
		_refresh_fuel_banner()


func _on_pm_grid_tripped() -> void:
	_grid_tripped = true
	_is_running   = false
	_sync_indicator()
	_sync_socket()
	if _inspect_ui != null and is_instance_valid(_inspect_ui) \
			and _inspect_ui.has_method("refresh"):
		var pm: PowerManager = get_tree().get_first_node_in_group("power_manager") as PowerManager
		var health: float = 100.0
		if pm != null:
			health = pm.get_generator_health(_pm_id)
		var gs: String = "TRIPPED"
		if pm != null:
			gs = pm.get_grid_state_string()
		_inspect_ui.call("refresh", _fuel_level, health, _is_backup, false, true, gs)


func _on_pm_grid_restored() -> void:
	_grid_tripped = false
	if _inspect_ui != null and is_instance_valid(_inspect_ui) \
			and _inspect_ui.has_method("refresh"):
		var pm: PowerManager = get_tree().get_first_node_in_group("power_manager") as PowerManager
		var health: float = 100.0
		if pm != null:
			health = pm.get_generator_health(_pm_id)
		var gs: String = "ONLINE"
		if pm != null:
			gs = pm.get_grid_state_string()
		_inspect_ui.call("refresh", _fuel_level, health, _is_backup, _is_running, false, gs)


func on_grid_tripped() -> void:
	_on_pm_grid_tripped()


func _exit_tree() -> void:
	# Inspector is root-owned; don't leave an orphan after deconstruction.
	if is_instance_valid(_inspect_ui):
		_inspect_ui.close()
		_inspect_ui.queue_free()
	var pm: PowerManager = get_tree().get_first_node_in_group("power_manager") as PowerManager
	if pm == null or _pm_id.is_empty():
		return
	## Wire node MUST be unregistered before generator to avoid dangling edges.
	if not _wire_key.is_empty():
		pm.unregister_wire_node(_wire_key)
	pm.unregister_generator(_pm_id)

# ─── Public API — called by PowerManager ──────────────────────────────────────
func set_powered(_on: bool) -> void:
	pass

func set_running(on: bool) -> void:
	_is_running = on
	_sync_indicator()
	_sync_socket()
	if _exhaust != null:
		_exhaust.emitting = on
	_request_inspect_refresh()

func set_fuel(level: float) -> void:
	_fuel_level = clampf(level, 0.0, 100.0)
	if _fuel_banner != null:
		_refresh_fuel_banner()
	_request_inspect_refresh()

# ─── Interaction prompt ───────────────────────────────────────────────────────
func get_interact_prompt() -> String:
	var fuel_pct: int = int(clampf(_fuel_level, 0.0, 100.0))
	var state_str: String
	if _is_backup:
		state_str = "Backup — Standby" if not _is_running else "Backup — Active"
	else:
		state_str = "Running" if _is_running else "Stopped"
	return "[E] %s  %d%% fuel  [%s]" % [_get_display_name(), fuel_pct, state_str]

func _get_display_name() -> String:
	var base: String = TIER_CONFIG[generator_tier].get("label", "Generator")
	return ("Backup " + base) if _is_backup else base

# ─── Interaction ──────────────────────────────────────────────────────────────
func on_interact() -> void:
	# ControllerUINavigation gates world interaction. Do not impersonate build
	# mode: the player must remain able to walk/turn while inspecting devices.
	if _inspect_ui == null or not is_instance_valid(_inspect_ui):
		var ui_script: GDScript = load("res://scripts/ui/power/GeneratorInspectUI.gd")
		if ui_script == null:
			push_warning("GeneratorObject: GeneratorInspectUI.gd not found")
			return
		_inspect_ui = CanvasLayer.new()
		_inspect_ui.set_script(ui_script)
		_inspect_ui.name = "GeneratorInspectUI"
		get_tree().get_root().add_child(_inspect_ui)
		if _inspect_ui.has_signal("closed"):
			_inspect_ui.closed.connect(_on_inspect_closed)
		if _inspect_ui.has_signal("backup_toggled"):
			_inspect_ui.backup_toggled.connect(_on_backup_toggled)
		if _inspect_ui.has_signal("power_toggled"):
			_inspect_ui.power_toggled.connect(_on_power_toggled)

	if _inspect_ui.has_method("open"):
		var pm:        PowerManager = get_tree().get_first_node_in_group("power_manager") as PowerManager
		var fuel:      float = _fuel_level
		var health:    float = 100.0
		var is_backup: bool  = _is_backup
		var gs:        String = "ONLINE"
		if pm != null and not _pm_id.is_empty():
			fuel      = pm.get_generator_fuel(_pm_id)
			health    = pm.get_generator_health(_pm_id)
			is_backup = pm.get_generator_is_backup(_pm_id)
			gs        = pm.get_grid_state_string()
		_inspect_ui.call("open", _get_display_name(),
			TIER_CONFIG[generator_tier].get("watts", 0),
			fuel, health, is_backup, _is_running, _grid_tripped, gs, self)


func _on_inspect_closed() -> void:
	pass # No gameplay lock was acquired by this inspector.


func _on_backup_toggled(enabled: bool) -> void:
	_is_backup = enabled
	var pm: PowerManager = get_tree().get_first_node_in_group("power_manager") as PowerManager
	if pm != null and not _pm_id.is_empty():
		pm.set_generator_backup(_pm_id, enabled)
	if pm != null:
		_is_running = pm.get_generator_running(_pm_id)
	_sync_indicator()
	_sync_socket()
	_refresh_inspect_ui()
	if _player_in_range and _fuel_banner != null:
		_refresh_fuel_banner()


func _on_power_toggled(desired_running: bool) -> void:
	var pm: PowerManager = get_tree().get_first_node_in_group("power_manager") as PowerManager
	if pm == null or _pm_id.is_empty():
		return

	## Real Burn trigger (Aug 2026) — "resetting a hazardous ... generator
	## carries a bounded burn chance, scaled visibly by the actual hazard
	## state involved," per docs/systems/medical/README.md. Only rolled when
	## actually STARTING the generator (not shutting it down), and captured
	## BEFORE reset_main_breaker()/set_generator_running() below change
	## either value, so the chance reflects the hazard the player was
	## actually reaching into.
	var was_grid_tripped: bool = _grid_tripped
	var grid_state_before: String = pm.get_grid_state_string()
	var health_before: float = pm.get_generator_health(_pm_id)

	## When the grid is TRIPPED and the player wants to start this generator,
	## reset the main breaker first (clears the trip). This is the manual
	## per-generator restart flow — player presses Start on each generator
	## individually to bring the grid back up.
	if desired_running and _grid_tripped:
		pm.reset_main_breaker()
		_grid_tripped = false   ## cleared locally; PM emits grid_restored for UI

	pm.set_generator_running(_pm_id, desired_running)
	_is_running = pm.get_generator_running(_pm_id)

	## Only a genuine "restart something hazardous" moment rolls the chance —
	## starting an already-fine, ungrid-tripped, full-health generator (the
	## ordinary case) never does. Matches BreakerBox._finish_restart()'s
	## exact shape (grid-state-scaled chance + a low-health bonus).
	if desired_running and (was_grid_tripped or health_before < PlayerMedical.ELECTRICAL_BURN_LOW_HEALTH_THRESHOLD):
		var player_medical: PlayerMedical = get_tree().get_first_node_in_group("player_medical") as PlayerMedical
		if player_medical != null:
			player_medical.roll_electrical_burn(grid_state_before, health_before)

	_sync_indicator()
	_sync_socket()
	_refresh_inspect_ui()
	if _player_in_range and _fuel_banner != null:
		_refresh_fuel_banner()


func _refresh_inspect_ui() -> void:
	if _inspect_ui == null or not is_instance_valid(_inspect_ui):
		return
	if not _inspect_ui.visible or not _inspect_ui.has_method("refresh"):
		return
	var pm:     PowerManager = get_tree().get_first_node_in_group("power_manager") as PowerManager
	var health: float = 100.0
	var gs:     String = "ONLINE"
	var fuel: float = _fuel_level
	var running: bool = _is_running
	var backup: bool = _is_backup
	if pm != null:
		health = pm.get_generator_health(_pm_id)
		gs     = pm.get_grid_state_string()
		fuel = pm.get_generator_fuel(_pm_id)
		running = pm.get_generator_running(_pm_id)
		backup = pm.get_generator_is_backup(_pm_id)
	_inspect_ui.call("refresh", fuel, health, backup, running, _grid_tripped, gs)


func _request_inspect_refresh() -> void:
	if _inspect_refresh_queued or not is_instance_valid(_inspect_ui) or not _inspect_ui.visible:
		return
	_inspect_refresh_queued = true
	_flush_inspect_refresh.call_deferred()


func _flush_inspect_refresh() -> void:
	_inspect_refresh_queued = false
	_refresh_inspect_ui()


func _on_inspector_power_changed(_draw: float, _capacity: float, _battery: float) -> void:
	_request_inspect_refresh()


func _on_inspector_grid_changed(_new_state: int, _old_state: int) -> void:
	_request_inspect_refresh()


func _sync_indicator() -> void:
	if _indicator_mat == null:
		return
	var col: Color = COLOR_RUNNING if _is_running else COLOR_STOPPED
	_indicator_mat.albedo_color = col
	_indicator_mat.emission     = col


func _get_main_world() -> Node:
	var root: Node = get_tree().get_root()
	for child: Node in root.get_children():
		if child is Node3D:
			return child
	return null


func _get_interaction_system() -> Node:
	var main_world: Node = _get_main_world()
	if main_world == null:
		return null
	for child: Node in main_world.get_children():
		if child is CharacterBody3D:
			for sub: Node in child.get_children():
				if sub.get_script() != null:
					var path: String = str(sub.get_script().resource_path)
					if path.contains("InteractionSystem"):
						return sub
	return null

## Side-effect-free ghost mesh for build-mode previews — extracted
## verbatim from GhostPreview.gd's inline TILE_GEN_S/M/L branch so the
## preview matches what the player actually places. No registration,
## no signals, no groups — just a plain Mesh.
static func build_ghost_mesh(tier: int = 0) -> Mesh:
	const GEN_SIZES: Array = [
		Vector3(0.57, 0.85, 0.85),
		Vector3(1.24, 1.13, 0.62),
		Vector3(1.85, 1.70, 0.925),
	]
	var box: BoxMesh = BoxMesh.new()
	box.size = GEN_SIZES[clamp(tier, 0, 2)]
	return box
